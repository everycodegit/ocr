/*
 * Digit0.hpp
 *
 *  Created on: Nov 11, 2018
 *      Author: peter1
 */

#ifndef DIGIT1_HPP_
#define DIGIT1_HPP_

#include "DigitCheckDefs.hpp"

class Digit0
{
public:
	// check whether or not it is 0, return confidence 0-100.
	static int 			check			(DigitCheckParams &digitInfo);
private:
	// check for multiple ways
	static int 			checkP1			(DigitCheckParams &digitInfo);
	static int 			checkP2			(DigitCheckParams &digitInfo);

};



#endif /* DIGIT1_HPP_ */
