/*
 * DigitCheckDefs.hpp
 *
 *  Created on: Nov 11, 2018
 *      Author: peter1
 */

#ifndef DIGITS_DIGITCHECKDEFS_HPP_
#define DIGITS_DIGITCHECKDEFS_HPP_

#define DIGIT_CHECK_MAX_ROW			50
#define DIGIT_CHECK_COL_PER_ROW		10
#define DIGIT_CHECK_MAX_TOTAL		(DIGIT_CHECK_MAX_ROW * DIGIT_CHECK_COL_PER_ROW)



struct DigitCheckParams
{
	int width, height;
	// represent white-black points change in every row, value is percentage of white/black points to width. when it is 0, means end of row
	// for example, first row (width=30): 3 black -> 20 white -> 7 black, result: points[0] = 0.1, points[1] = 0.67, points[2] = 0.23, points[3] = 0
	double 		points[DIGIT_CHECK_MAX_TOTAL];
	// weight of white pixel in a row, percentage, 0-1.0
	double 		weights[DIGIT_CHECK_MAX_ROW];
};



#endif /* DIGITS_DIGITCHECKDEFS_HPP_ */
