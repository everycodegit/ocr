/*
 * Digit0.cpp
 *
 *  Created on: Nov 11, 2018
 *      Author: peter1
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Digit0.hpp"
#include "DigitUtils.hpp"

int Digit0::check(DigitCheckParams &digitInfo)
{
	// check for multiple ways
	int pos = checkP1(digitInfo);
	if (!pos) pos = checkP2(digitInfo);
	return pos;
}


/** check for normal style, black circle in center. */
int Digit0::checkP1(DigitCheckParams &digitInfo)
{
	int beginRow = -1, endRow = -1, beginCol = -1, endCol = -1;
	int itmp = 0;
	if (DigitUtils::FindCircle(digitInfo, false, 0, 0, beginRow, endRow, beginCol, endCol)) {
		// calculate offset of circle from center row.
		// if startRow and endRow are same distnace from center row, itmp = 0;
		itmp = digitInfo.height - beginRow - endRow;
		if (abs(itmp) < 5) return 100;
		else {
			printf("Find 0: %d\n", itmp);
		}
	}
	return 0;
}

int Digit0::checkP2(DigitCheckParams &digitInfo)
{
	return 0;
}
