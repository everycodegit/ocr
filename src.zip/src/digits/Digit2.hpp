/*
 * Digit2.hpp
 *
 *  Created on: Nov 12, 2018
 *      Author: peter1
 */

#ifndef DIGITS_DIGIT2_HPP_
#define DIGITS_DIGIT2_HPP_


#include "DigitCheckDefs.hpp"

class Digit2
{
public:
	// check whether or not it is 0, return confidence 0-100.
	static int 			check			(DigitCheckParams &digitInfo);
private:
	// check for multiple ways
	static int 			checkP1			(DigitCheckParams &digitInfo);
	static int 			checkP2			(DigitCheckParams &digitInfo);

};



#endif /* DIGITS_DIGIT2_HPP_ */
