/*
 * Digit2.cpp
 *
 *  Created on: Nov 12, 2018
 *      Author: peter1
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Digit2.hpp"
#include "DigitUtils.hpp"

int Digit2::check(DigitCheckParams &digitInfo)
{
	// check for multiple ways
	int pos = checkP1(digitInfo);
	if (!pos) pos = checkP2(digitInfo);
	return pos;
}


/** check for normal style, black circle in center. */
int Digit2::checkP1(DigitCheckParams &digitInfo)
{
	printf("Find 2: \n");
	Rect rect;
	// bottom large white
	if (DigitUtils::FindLongHorizontalLine(digitInfo, true, digitInfo.height * 2 / 3, rect)) {
		if ((digitInfo.height - rect.y - rect.height) > 3) {
			printf("Invalid line position: %d\n", rect.y);
			return 0;
		}
		return 100;
	}
	// find top black/white/black
	// 2 white at top part
	// middle single white at bottom part
	return 0;
}

int Digit2::checkP2(DigitCheckParams &digitInfo)
{
	return 0;
}



