/*
 * DigitUtils.cpp
 *
 *  Created on: Nov 11, 2018
 *      Author: peter1
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <algorithm>
#include "DigitUtils.hpp"
#include "Digit0.hpp"
#include "Digit2.hpp"

int DigitUtils::FindDigit(DigitCheckParams &digitInfo)
{
	char chr = 0;
	int conf = Digit0::check(digitInfo);
	if (conf) return '0';
	if (!conf) conf = Digit2::check(digitInfo);
	if (conf) return '2';

	return chr;
}


// find a circle starting from startRow, startCol for color type white (true - find white circle, false, find black circle).
// white circle should be a circle surrounded by black pixel. black circle should be surrounded by white pixel;
// if circle found, return true: circle info: beginRow, endRow, beginCol, endCol;
bool DigitUtils::FindCircle(DigitCheckParams &digitInfo, bool white,
				int startRow, int startCol,
				int &beginRow, int &endRow, int &beginCol, int &endCol)
{
	printf("Find circle:\n");
	int rstart = -1, rend = -1;
	int cstart = -1,cend = -1;
	double circle[DIGIT_CHECK_MAX_ROW * 2]; // [start position, width]
	memset(circle, 0, sizeof(double) * DIGIT_CHECK_MAX_ROW * 2);
	double adj = -1.0f;
	if (!white) adj = 1.0f;
	double dtmp1, dtmp2, dtmp3;
	char temp[300];
	for (int i=0;i<digitInfo.height && i < DIGIT_CHECK_MAX_ROW;i++) {
		dtmp1 = digitInfo.points[i * DIGIT_CHECK_COL_PER_ROW] * adj;
		dtmp2 = digitInfo.points[i * DIGIT_CHECK_COL_PER_ROW + 1] * adj;
		dtmp3 = digitInfo.points[i * DIGIT_CHECK_COL_PER_ROW + 2] * adj;
		// if it is white -> black, or black->white->black
		if (dtmp1 < 0 && dtmp3 < 0) {
			circle[i * 2] = fabs(dtmp1 + dtmp2);
			circle[i * 2 + 1] = fabs(dtmp3);
		} else if (dtmp1 > 0 && dtmp2 < 0) {
			circle[i * 2] = fabs(dtmp1);
			circle[i * 2 + 1] = fabs(dtmp2);
		} else if (dtmp1 < 0 && dtmp2 == 0) {
			// only black
			circle[i * 2 + 1] = 1;
		} else if (dtmp1 > 0 && dtmp2 == 0) {
			// only white
			circle[i * 2 + 1] = -1;
		}
		printf("find circle: %d - %1.2f,%1.2f [%1.2f,%1.2f,%1.2f]\n",
				i, circle[i * 2], circle[i * 2 + 1], dtmp1, dtmp2, dtmp3);
	}
	// find
	int step =0;
	dtmp1 = circle[1];
	rstart = -1;
	rend = -1;
	cstart = -1;
	cend = -1;
	for (int i=1;i<digitInfo.height && i < DIGIT_CHECK_MAX_ROW;i++) {
		// TODO
		// need add buffer when width slightly changes.
		if (circle[i * 2 + 1] == dtmp1) continue;
		if (circle[i * 2 + 1] < dtmp1) {
			// go down
			if (step == 1) {
				printf("go down, %d\n", i);
				step = 2;
			} else if (step == 0) {
				rstart = -1;
				cstart = -1;
			} else {
				// step == 2,
				// it is ok
			}
		} else {
			// go up
			if (rstart < 0) {
				printf("go up, %d\n", i);
				step = 1;
				rstart = i;
				cstart = circle[i * 2] * digitInfo.width;
			} else if (step == 2) {
				printf("found, %d\n", i);
				rend = i;
				cend = circle[i * 2] * digitInfo.width;
				step = 0;
				break;
			}
		}
		dtmp1 = circle[i * 2 + 1];
	}
	if (step == 2) {
		rend = digitInfo.height - 1;
	}
	if (rstart >= 0 && rend >= 0) {
		beginRow = rstart;
		endRow = rend;
		beginCol = cstart;
		endCol = cend;
		return true;
	}
	return false;
}

/** get first white/black position in a row. return -1 if not found */
double DigitUtils::GetFirstPos(DigitCheckParams &digitInfo, int row, bool white)
{
	if (row >= digitInfo.height || row >= DIGIT_CHECK_MAX_ROW)
		return -1;
	double adj = 1.0f;
	if (!white) adj = -1.0f;
	double dpos = 0;
	double dtmp;
	int endCol = std::min(digitInfo.width, DIGIT_CHECK_COL_PER_ROW);
	for (int i=0;i<endCol;i++) {
		dtmp = digitInfo.points[row * DIGIT_CHECK_COL_PER_ROW + i] * adj;
		// encounter first white
		if (dtmp > 0) {
			return dpos;
		}
		dpos += fabs(dtmp);
	}
	return -1.0f;
}

/** get end position of last white/black in a row. */
double DigitUtils::GetEndPos(DigitCheckParams &digitInfo, int row, bool white)
{
	if (row >= digitInfo.height || row >= DIGIT_CHECK_MAX_ROW)
		return -1;
	double adj = 1.0f;
	if (!white) adj = -1.0f;
	double dpos = 0;
	double dtmp;
	int endCol = std::min(digitInfo.width - 1, DIGIT_CHECK_COL_PER_ROW - 1);
	for (int i=endCol;i>=0;i--) {
		dtmp = digitInfo.points[row * DIGIT_CHECK_COL_PER_ROW + i] * adj;
		// encounter first white
		if (dtmp > 0) {
			return (1.0f - dpos);
		}
		dpos += fabs(dtmp);
	}
	return -1.0f;
}


bool DigitUtils::FindLongHorizontalLine(DigitCheckParams &digitInfo, bool white, int startRow, Rect &lineRect)
{
	double adj = 1.0f;
	if (!white) adj = -1.0f;
	// get total weight of 3 rows in sequence
	double shape[DIGIT_CHECK_MAX_ROW * 2]; // [start position, width]
	memset(shape, 0, sizeof(double) * DIGIT_CHECK_MAX_ROW * 2);
	int endRow = std::min(digitInfo.height - 3, DIGIT_CHECK_MAX_ROW - 3);
	double dtmp1 = 0, dtmp2 = 0, dtmp3 = 0;
	bool cont = true;
	// find 3 sequential similar line (same weight) and calculate their total weights
	for (int i=startRow; i<endRow; i++) {
		// they need to either start vertically or end vertically
		dtmp1 = digitInfo.points[i * DIGIT_CHECK_COL_PER_ROW] * adj;
		dtmp2 = digitInfo.points[(i + 1) * DIGIT_CHECK_COL_PER_ROW] * adj;
		dtmp3 = digitInfo.points[(i + 2) * DIGIT_CHECK_COL_PER_ROW] * adj;
		cont = true;
		if ((dtmp1 < dtmp2 && dtmp2 < dtmp3)
				|| (dtmp1 > dtmp2 && dtmp2 > dtmp3)) {
			// not vertical
			cont = false;;
		}
		printf("line [%02d] : %1.2f,%1.2f,%1.2f - %d\n", i, dtmp1, dtmp2, dtmp3, cont);
		dtmp1 = GetEndPos(digitInfo, i, white);
		dtmp2 = GetEndPos(digitInfo, i + 1, white);
		dtmp3 = GetEndPos(digitInfo, i + 2, white);
		cont = true;
		if (dtmp1 == -1 || dtmp2 == -1 || dtmp3 == -1
			|| (dtmp1 < dtmp2 && dtmp2 < dtmp3)
				|| (dtmp1 > dtmp2 && dtmp2 > dtmp3)) {
			// not vertical
			cont = false;;
		}
		printf("line [%02d]1: %1.2f,%1.2f,%1.2f - %d, %1.2f,%1.2f,%1.2f\n",
				i, dtmp1, dtmp2, dtmp3, cont,
				digitInfo.weights[i], digitInfo.weights[i+1], digitInfo.weights[i+2]);
		if (!cont) {
			// can't find vertical start/end
			continue;
		}
		// check start position with end position together to see if it increases/decreases.



		// get white start position
		if (dtmp1 > 0) {
			shape[i*2] = digitInfo.points[i * DIGIT_CHECK_COL_PER_ROW];
		}
		dtmp1 = (digitInfo.weights[i] + digitInfo.weights[i+1] + digitInfo.weights[i+2]) / 3.0f;
		if (dtmp1 < 0.7) {
			// not long enough
			continue;
		}
		dtmp2 = 3.0 / digitInfo.width; // 3 pixel difference
		printf("  weight: %1.2f,%1.2f,%1.2f,%1.2f\n", digitInfo.weights[i], digitInfo.weights[i+1], digitInfo.weights[i+2], dtmp2);
		if (fabs(digitInfo.weights[i] - dtmp1) <= dtmp2
				&& fabs(digitInfo.weights[i + 1] - dtmp1) <= dtmp2
				&& fabs(digitInfo.weights[i + 2] - dtmp1) <= dtmp2
				&& fabs(digitInfo.weights[i] - digitInfo.weights[i + 1]) <= dtmp2
				&& fabs(digitInfo.weights[i] - digitInfo.weights[i + 2]) <= dtmp2
				&& fabs(digitInfo.weights[i + 2] - digitInfo.weights[i + 1]) <= dtmp2) {
			shape[i*2 + 1] = digitInfo.weights[i];
			shape[i*2 + 1] += digitInfo.weights[i+1];
			shape[i*2 + 1] += digitInfo.weights[i+2];
		}
	}
	// check whether or there are 3 sequential similar line, and find max weight of the line
	dtmp1 = 0;
	for (int i=startRow; i<endRow; i++) {
		if (shape[i*2 + 1] > dtmp1) {
			printf("Found hor line %d, %1.2f\n", i, shape[i*2 + 1]);
			lineRect.y = i;
			lineRect.x = shape[i*2] * digitInfo.width;
			lineRect.width = shape[i*2] * digitInfo.width / 3;
			lineRect.height = 3;
			dtmp1 = shape[i*2 + 1];
		}
	}
	// TODO, find similar weight before/after this row to find real
	if (dtmp1 > 1.8f) return true;
	return false;
}

