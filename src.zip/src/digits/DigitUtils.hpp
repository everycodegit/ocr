/*
 * DigitUtils.hpp
 *
 *  Created on: Nov 11, 2018
 *      Author: peter1
 */

#ifndef DIGITS_DIGITUTILS_HPP_
#define DIGITS_DIGITUTILS_HPP_

#include "DigitCheckDefs.hpp"

#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
using namespace cv;

class DigitUtils
{
public:
	// check whether or not it is 0, return confidence 0-100.
	static int 			FindDigit					(DigitCheckParams &digitInfo);

	// find a circle starting from startRow, startCol for color type white (true - find white circle, false, find black circle).
	// white circle should be a circle surrounded by black pixel. black circle should be surrounded by white pixel;
	// if circle found, return true: circle info: beginRow, endRow, beginCol, endCol;
	static bool			FindCircle					(DigitCheckParams &digitInfo, bool white,
													int startRow, int startCol,
													int &beginRow, int &endRow, int &beginCol, int &endCol);
	static bool			FindLongHorizontalLine		(DigitCheckParams &digitInfo, bool white, int startRow, Rect &lineRect);
	/** get first white/black position in a row. */
	static double		GetFirstPos					(DigitCheckParams &digitInfo, int row, bool white);
	/** get end position of last white/black in a row. */
	static double		GetEndPos					(DigitCheckParams &digitInfo, int row, bool white);
};



#endif /* DIGITS_DIGITUTILS_HPP_ */
