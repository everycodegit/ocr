/*
 * FindArea.hpp
 *
 *  Created on: Dec 3, 2018
 *      Author: peter1
 */

#ifndef FINDAREA_HPP_
#define FINDAREA_HPP_

#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/photo.hpp>
#include <opencv2/features2d.hpp>
using namespace cv;
#include <vector>
#include <list>
using namespace std;


class FindArea
{
private:
	int 		mMaxBlobDist;
public:
				FindArea				();
	bool 		FindTextArea			(Mat &img, Mat &area1, Mat &area2, Rect &area1Rect, Rect &area2Rect);

private:
	void 		RemoveIsolatedBlob		(vector<vector<Point>> contours, vector<vector<Point>> &newCont);
	bool 		AddCloseBlob			(Rect &rect, vector<vector<Point>> &contours);
	bool 		MergeRect				(vector<Rect> &rects);
	void 		FixRect					(vector<Rect> &rects, Mat &img);
	void 		RemoveExtraRect			(Rect &rect, Mat &img, int seqno);
	void 		FindBlob				(Mat &toUse, Mat &org, Rect &area1Rect, Rect area2Rect);
	int 		ReprcImageTest			(Mat &img, Mat &out, int vopen, int vclose);
	int 		rectDistance			(Rect &rect, Rect &rect1);
	void 		ReprcImage				(Mat &img, int index);

};



#endif /* FINDAREA_HPP_ */
