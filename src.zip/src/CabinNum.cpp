/*
 * ocr.cpp
 *
 *  Created on: May 15, 2018
 *      Author: peter1
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/stat.h>
#include <linux/rtc.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#include <sys/ioctl.h>
#include <sys/statvfs.h>
#include <dirent.h>
#include <time.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netdb.h>
#include <ifaddrs.h>
#include <linux/if_link.h>
#include <netinet/in.h>
#include <arpa/nameser.h>
#include <resolv.h>
#include <vector>
#include <algorithm>
#include <string>
#include <iostream>
#include <fstream>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <list>

#include "ProcImg.hpp"
#include "Utils.hpp"

/*
void pic(const char *filename)
{
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);

	Mat img = imread(filename, 0);
	Mat tmpl = imread("5-60.jpg", 0);
	Mat tmp2 = imread("0-60.jpg", 0);
	Mat result;
	matchTemplate(img, tmpl, result, CV_TM_CCOEFF_NORMED);
	double maxVal;
	Point maxLoc;
	minMaxLoc(result, NULL, &maxVal, NULL, &maxLoc);
	threshold(result, result, maxVal - 0.09, 255, THRESH_BINARY);
	imwrite("match.jpg", result, params);
	// find location
	int channels = result.channels();
	uchar *pline = NULL;
	std::list<CharInfo> chars;
	CharInfo ci;
	int evalue = 0;
	Vec3b vc;
	for (int i=0;i<result.cols;i++) {
		//pline = result.ptr<uchar*>(i);
		for (int j=0;j<result.rows;j++) {
			vc = result.at<Vec3b>(j,i);
			// if (evalue != 0) {
			if (vc.val[0] != 0) {
				ci.ch = '5';
				ci.x = i;
				ci.y = j;
				i += 10; // skip half size of char
				chars.push_back(ci);
				break;
			}
		}
	}
	printf("match: %1.2f, cn: %d\n, ch:%d", maxVal, chars.size(), channels);
	Mat result1;
	matchTemplate(img, tmp2, result1, CV_TM_CCOEFF_NORMED);
	minMaxLoc(result1, NULL, &maxVal, NULL, &maxLoc);
	threshold(result1, result1, maxVal - 0.09, 255, THRESH_BINARY);
	for (int i=0;i<result1.cols;i++) {
		//pline = result.ptr<uchar*>(i);
		for (int j=0;j<result1.rows;j++) {
			if (result1.at<uchar>(j,i) != 0) {
				ci.ch = '0';
				ci.x = i;
				ci.y = j;
				i += 10; // skip half size of char
				chars.push_back(ci);
				break;
			}
		}
	}
	imwrite("match0.jpg", result1, params);
	printf("match 0: %1.2f, cn:%d\n", maxVal, chars.size());
}
*/

void checkAll()
{
	char outText[100];
	ProcImg prcimg;
	DIR *dir = opendir ("./");
	char temp[100];
	remove("result.txt");
	if (dir) {
		struct dirent *ent;
		// *****
		// note, readdir is not threadsafe, if multiple place will use this
		// function, then must be put into mutex and rewrite function
		while ((ent = readdir (dir)) != NULL) {
			if (ent->d_type != DT_REG) continue;
			if (strncmp(ent->d_name, "c-", 2) == 0
					&& strstr(ent->d_name, ".jpg")) {
				sprintf(temp, "process: %s:\n", ent->d_name);
				prcimg.ProcessImage(ent->d_name, outText, 10);
				sprintf(temp, "%s:\t%s\n", ent->d_name, outText);
				Utils::UpdateDataToFile("result.txt", (const unsigned char *) temp, strlen(temp), -1);
			}
		}
		closedir (dir);
	}

}

int main(int argc, char **argv)
{
	const char *filename = "train.jpg";
	if (argc >= 2) {
		filename = argv[1];
		char outText[100];
		ProcImg prcimg;
		prcimg.ProcessImage(filename, outText, 10);
	} else {
		checkAll();
	}
    return 0;
}
