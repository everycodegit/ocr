/*
 * ProcTypes.hpp
 *
 *  Created on: Nov 17, 2018
 *      Author: peter1
 */

#ifndef PROCTYPES_HPP_
#define PROCTYPES_HPP_

#include <list>
#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
using namespace cv;

#define			MAX_IMG_PER_CHAR	10
#define			MAX_CHAR_TYPE		10 * MAX_IMG_PER_CHAR


struct CharTemp
{
	char		ch;
	int			width;
	int			height;
	cv::Mat 		*pMat;
};


struct ContInfo
{
	long	area;
	Rect 	rect;
};



struct DigitInfo
{
	char chr;
	Rect rect;
	std::list<ContInfo> cis;
};


struct CharInfo
{
	char ch;
	int  x;
	int  y;
};


struct ProcParams
{
	int					MinCharHeight, MaxCharHeight;
	int					MinCharWidth, MaxCharWidth;
};


#endif /* PROCTYPES_HPP_ */
