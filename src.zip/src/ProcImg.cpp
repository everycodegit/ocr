/*
 * ProcImg.cpp
 *
 *  Created on: Nov 7, 2018
 *      Author: peter1
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <sys/stat.h>
#include <linux/rtc.h>
#include <fcntl.h>
#include <linux/ioctl.h>
#include <sys/ioctl.h>
#include <sys/statvfs.h>
#include <dirent.h>
#include <time.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netdb.h>
#include <ifaddrs.h>
#include <linux/if_link.h>
#include <netinet/in.h>
#include <arpa/nameser.h>
#include <resolv.h>
#include <vector>
#include <algorithm>
#include <string>
#include <iostream>
#include <fstream>
#include <signal.h>
#include <errno.h>
#include <unistd.h>

#include "ProcTypes.hpp"
#include "ProcImg.hpp"

#include <opencv2/core/core.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/photo.hpp>
using namespace cv;

#include <list>

#include "Utils.hpp"
#include "digits/DigitCheckDefs.hpp"
#include "digits/Digit0.hpp"
#include "digits/DigitUtils.hpp"

struct ProcParams gParams;


ProcImg::ProcImg()
{
	gParams.MinCharHeight = 20;
	gParams.MaxCharHeight = 34;
	gParams.MinCharWidth = 3;
	gParams.MaxCharWidth = 28;
	//mpCheckChar = new CheckChar();
}

ProcImg::~ProcImg()
{

}


void ProcImg::MatchTmpl(char chr, Mat &img, Mat &tmpl, Mat &result, std::list<CharInfo*> &chars)
{
	matchTemplate(img, tmpl, result, CV_TM_CCOEFF_NORMED);
	double maxVal;
	Point maxLoc;
	minMaxLoc(result, NULL, &maxVal, NULL, &maxLoc);
	printf("Match %c: %1.2f\n", chr, maxVal);
	// don't do anything if no template found;
	if (maxVal < 0.70) return;
	double val = maxVal - 0.15;
	if (val < 0.7) val = 0.7;
	val = 0.71;
	threshold(result, result, val, 255, THRESH_BINARY);
	//printf("searching %c\n", chr);
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);
	if (chr == '8') {
		imwrite("match.jpg", result, params);
	}
	//imwrite("match.jpg", result, params);
	// find location
	CharInfo *ci, *pci;
	// Vec3b vc;
	int px;
	std::list<CharInfo*>::iterator it, end;
	bool found = false;
	for (int i=0;i<result.cols;i++) {
		for (int j=0;j<result.rows;j++) {
			//vc = result.at<Vec3b>(j,i);
			//if (vc.val[0] != 0 || vc.val[1] != 0 || vc.val[2] != 0) {
			px = result.at<int>(j,i);
			if (px != 0) {
				printf("found %c\n", chr);
				ci = new CharInfo;
				ci->ch = chr;
				ci->x = i;
				ci->y = j;
				// find correct position.
				found = false;
				end = chars.end();
				for (it = chars.begin(); it != end; it++) {
					pci = (*it);
					if (pci->x >= i) {
						chars.insert(it, ci);
						found = true;
						break;
					}
				}
				if (!found) {
					chars.push_back(ci);
				}
				i += (tmpl.cols * 2 / 3); // skip half size of char
				break;
			}
		}
	}
}



/*
// good
bool FindABox(std::list<ContInfo>::iterator &nit,	std::list<ContInfo>::iterator end, std::list<ContInfo> &cis, Rect &outRect, int locX, int locY, int height)
{
	if (nit == end) return false;
	Rect rect = (*nit).rect;
	cis.clear();
	// cis.push_back((*nit));
	int itmp;
	for (;nit != end; nit++) {
		printf("........ check: %d,%d,%d,%d\n", (*nit).rect.x, (*nit).rect.y, (*nit).rect.width, (*nit).rect.height);
		// too wide
		if ((*nit).rect.width >= gParams.MaxCharWidth) {
			// if the piece is out of section, skip it
			if (locY != 0 && ((locY + 5) > ((*nit).rect. y + (*nit).rect.height)
					|| (locY + height - 5) < (*nit).rect. y)) {
				printf("skip 1\n");
				continue;
			}
			// if it is not in
			break;
		}
		// skip the piece which is not in current digit rectangle
		if (locX != 0 && locX >= ((*nit).rect.x + (*nit).rect.width)) {
			printf("skip 2\n");
			continue;
		}
		if ((*nit).rect.height >= gParams.MaxCharHeight) {
			printf("skip 3\n");
			break;
		}
		if (locY + 5 > (*nit).rect.y + (*nit).rect.height) {
			printf("skip 4\n");
			continue;
		}
		//if (locY == 0) {
		//	itmp = (*nit).rect.x + (*nit).rect.width - rect.x;
		//}
		// make sure it is not overlap with height
		//if (rect.y + 5 > ((*nit).rect.y + (*nit).rect.height))
		//	continue;
		//else break; // invalid piece between it.
		itmp = (*nit).rect.x + (*nit).rect.width - rect.x;
		if (itmp > gParams.MaxCharWidth || itmp < 0)
			break;
		itmp = (*nit).rect.y + (*nit).rect.height - rect.y;
		if (itmp > gParams.MaxCharHeight || itmp < 0)
			break;
		// nit.rect.y might smaller than current rect.
		itmp = (*nit).rect.y + (*nit).rect.height - (*nit).rect.y;
		if (itmp > gParams.MaxCharHeight || itmp < 0)
			break;

		if ((*nit).rect.y < rect.y) rect.y = (*nit).rect.y;
		itmp = (*nit).rect.x + (*nit).rect.width - rect.x;
		if (itmp > rect.width) rect.width = itmp;
		itmp = (*nit).rect.y + (*nit).rect.height - rect.y;
		if (itmp > rect.height) rect.height = itmp;
		cis.push_back((*nit));
		printf("........ added\n");
	}
	if (rect.height >= gParams.MinCharHeight && rect.height < gParams.MaxCharHeight
			&& rect.width < gParams.MaxCharWidth && rect.width >= gParams.MinCharWidth) {
		outRect = rect;
		return true;
	}
	return false;
}
*/

/*
// good
bool FindABox(std::list<ContInfo>::iterator &nit,	std::list<ContInfo>::iterator end, std::list<ContInfo> &cis,
		Rect &outRect, int locX, int locY, int width, int height, bool &is1, int digitIndex)
{
	if (nit == end) return false;
	Rect rect = (*nit).rect;
	cis.clear();
	int cnt = 0;
	// cis.push_back((*nit));
	int itmp;
	for (;nit != end; nit++) {
		++cnt;
		printf("........ check: %d,%d,%d,%d\n", (*nit).rect.x, (*nit).rect.y, (*nit).rect.width, (*nit).rect.height);
		// check whether it is 1
		itmp = (*nit).rect.height - height;
		if (locX != 0 && itmp <= 5 && itmp >= -5
				&& (*nit).rect.width >= 2 && (*nit).rect.width <= 8) {
			if (cnt == 1) {
				nit++;
				printf("stop for 1\n");
				is1 = true;
				break;
			}

			// TODO??? handle 1 when it is at third digit or other digit
			bool cont = false;
			// if it is digit after third digit, "1" must be at fist or not too far from beginning
			if (cnt != 0) {
				if (((*nit).rect.x + (*nit).rect.width - locX) < 13)
					cont = true; // continue with digit 1.
			}
			// continue with digit 1 or just a piece of other digit.
			if (cont) {
				is1 = true;
				if (rect.height >= 10 || rect.width >= 10) {
					// skip first one
					if (cnt == 1) nit++;
					break;
				}
				// otherwise, skip existing pieces
				rect = (*nit).rect;
				printf("stop 1\n");
				break;
			}
		}
		// skip the piece which is not in current digit rectangle
		if (width != 0 && (locX + width  + 8) <= ((*nit).rect.x + (*nit).rect.width)) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 2\n");
			break;;
		}
		// stop when piece is out of box from height
		if ((height > 0 && ((*nit).rect.y + (*nit).rect.height - locY) > (height + 5))
			|| (*nit).rect.height >= gParams.MaxCharHeight) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 3\n");
			break;
		}
		if (locY + 5 > (*nit).rect.y + (*nit).rect.height) {
			printf("skip 4\n");
			continue;
		}
		//if (locY == 0) {
		//	itmp = (*nit).rect.x + (*nit).rect.width - rect.x;
		//}
		// make sure it is not overlap with height
		//if (rect.y + 5 > ((*nit).rect.y + (*nit).rect.height))
		//	continue;
		//else break; // invalid piece between it.
		itmp = (*nit).rect.x + (*nit).rect.width - rect.x;
		if (itmp > gParams.MaxCharWidth || itmp < 0) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 5\n");
			break;
		}
		itmp = (*nit).rect.y + (*nit).rect.height - rect.y;
		if (itmp > gParams.MaxCharHeight || itmp < 0) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 6\n");
			break;
		}
		// nit.rect.y might smaller than current rect.
		itmp = (*nit).rect.y + (*nit).rect.height - (*nit).rect.y;
		if (itmp > gParams.MaxCharHeight || itmp < 0) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 7\n");
			break;
		}

		if ((*nit).rect.y < rect.y) rect.y = (*nit).rect.y;
		itmp = (*nit).rect.x + (*nit).rect.width - rect.x;
		if (itmp > rect.width) rect.width = itmp;
		itmp = (*nit).rect.y + (*nit).rect.height - rect.y;
		if (itmp > rect.height) rect.height = itmp;
		cis.push_back((*nit));
		printf("........ added\n");
	}
	//
	if (height != 0 && ((rect.height + 5) < height || (rect.height - 4) > height)) {
		printf("    fail 1\n");
		return false;
	}
	if ((height == 0 || (rect.height + 5 > height && (rect.height - 5) < height))
		&& rect.height >= gParams.MinCharHeight && rect.height < gParams.MaxCharHeight
		&& rect.width < gParams.MaxCharWidth && rect.width >= gParams.MinCharWidth) {
		outRect = rect;
		if (rect.width < 8 && cis.size() == 1) is1 = true;
		return true;
	}
	printf("    fail 2 : %d,%d,%d,%d,   %dx%d\n", rect.x, rect.y, rect.width, rect.height, width, height);
	return false;
}


void ProcImg::FindDigits(std::list<ContInfo> &conts, std::list<DigitInfo> &digits, std::list<ContInfo>::iterator it,
		std::list<ContInfo>::iterator end, int &maxWidth, int &minWidth)
{
	std::list<ContInfo> cis;
	Rect outRect;
	std::list<ContInfo>::iterator nit;
	Rect firstRect = Rect(0,0,0,0);
	int locX = 0, locY = 0, width = 0, height = 0;
	int itmp = 0;
	DigitInfo di;
	bool is1 = false;
	// find first digit
	int digitIndex = 0;
	for (;it != end;) {
		// find a cont
		printf("... finding: %d,%d,%d,%d\n", (*it).rect.x, (*it).rect.y, (*it).rect.width, (*it).rect.height);
		// find a large piece for first digit.
		if (locY == 0 && ((ContInfo&) (*it)).area < 30) {
			++it;
			continue;
		}
		nit = it;
		is1 = false;
		if (FindABox(nit, end, cis, outRect, locX, locY, width, height, is1, digitIndex)) {
			di.rect = outRect;
			di.cis = cis;
			if (is1) {
				printf("find 1\n");
				di.chr = '1';
			}
			else di.chr = 0;

			it = nit;
			printf("Found a box: %d,%d,%d,%d\n",
					outRect.x, outRect.y, outRect.width, outRect.height);
			if (locY == 0) {
				locY = outRect.y;
				height = outRect.height;
				width = outRect.width;
			}
			itmp = outRect.y - locY;
			// update y location because it can change (not always at same line)
			if (itmp < 5 && itmp > -5) locY = outRect.y;
			// mini x poistion for next char
			locX = outRect.x + outRect.width - 3;
			digits.push_back(di);
			if (outRect.width > maxWidth) maxWidth = outRect.width;
			if (!is1 && outRect.width < minWidth) minWidth = outRect.width;
			++digitIndex;
		} else it++;
	}
}
*/

/*
bool ProcImg::MatchDigit(DigitInfo &di, Mat &org, int index, int minWidth, int maxWidth, int nextX)
{
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);
	Rect rect = di.rect;
	Mat dig;
	if ((di.rect.width + 5) < maxWidth && (di.rect.x + di.rect.width + 5) < nextX) {
		// adjust width
		rect.width += 3;
		dig = org(rect);
	} else {
		if ((rect.width + 3) < maxWidth)
			rect.width += 1;
		dig = org(rect);
	}
	char temp[100];
	sprintf(temp, "get-%d.jpg", index);
	imwrite(temp, dig, params);
	Mat tocomp;
	int col, row;
	double maxVal, minVal;
	Point maxLoc;
	Mat result;
	char chr = 0;
	double conf = 0;
	//double matchShapes(InputArray contour1, InputArray contour2, int method, double parameter);
	for (int i=0;i<MAX_CHAR_TYPE;i++) {
		if (mpChars[i].pMat) {

			//double matchShapes(InputArray contour1, InputArray contour2, int method, double parameter);
			printf("Match %c: %1.2f-%1.2f\n", mpChars[i].ch, maxVal,minVal);
			if (maxVal > conf) {
				conf = maxVal;
				chr = mpChars[i].ch;
			}
		}
	}
	if (conf > 0) {
		di.chr = chr;
	}
	return (conf > 0);
}
*/

/*
bool ProcImg::DetermineDigit(DigitInfo &di, Mat &org, int index, int minWidth, int maxWidth, int nextX)
{
	DigitCheckParams digParams;
	memset(&digParams, 0, sizeof(DigitCheckParams));
	int white = 0, black = 0;
	// calculate points
	int pix;
	int db;
	int lastPix;
	int seq = 0;
	digParams.width = di.rect.width;
	digParams.height = di.rect.height;
	char temp[300];
	//char ttt[500];
	for (int i=0;i<digParams.height && i<DIGIT_CHECK_MAX_ROW;i++) {
		white = 0;
		black = 0;
		lastPix = -1;
		seq = 0;
		//ttt[0] = '\0';
		for (int j=0;j<digParams.width;j++) {
			db = (int) org.at<uchar>(i + di.rect.y, j + di.rect.x);
			pix = (db != 0);
			//sprintf(temp, "%d ", db);
			//strcat(ttt, temp);
			if (lastPix != -1 && ((lastPix && !pix) || (!lastPix && pix))) {
				// pix changed
				if (white != 0 && seq < DIGIT_CHECK_COL_PER_ROW) {
					digParams.points[i * DIGIT_CHECK_COL_PER_ROW + seq] = white * 1.0f / digParams.width;
				}
				if (black != 0 && seq < DIGIT_CHECK_COL_PER_ROW) {
					digParams.points[i * DIGIT_CHECK_COL_PER_ROW + seq] = black * (-1.0f) / digParams.width;
				}
				++seq;
				white = 0;
				black = 0;
			}
			if (pix) ++white;
			else ++black;
			lastPix = (pix !=0);
		}
		if (white != 0 && seq < DIGIT_CHECK_COL_PER_ROW) {
			digParams.points[i * DIGIT_CHECK_COL_PER_ROW + seq] = white * 1.0f / digParams.width;
		}
		if (black != 0 && seq < DIGIT_CHECK_COL_PER_ROW) {
			digParams.points[i * DIGIT_CHECK_COL_PER_ROW + seq] = black * (-1.0f) / digParams.width;
		}
		//printf("%s\n", ttt);
	}
	// don't remove noise, any 1 pixel counts
	// remove noise, remove point that only 1 pixel exists
	double per1 = 1.0f / digParams.width + 0.01;
	double dtmp, dtmp1, dtmp2;

//	for (int i=0;i<DIGIT_CHECK_MAX_ROW && i<digParams.height;i++) {
//		for (int j=0;j<DIGIT_CHECK_COL_PER_ROW;j++) {
//			dtmp = fabs(digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j]);
//			// if it is only 1 pixel, remove it and add it to next
//			if (dtmp > per1) continue;
//			digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j] = 0;
//			// if it is not last one, otherwise, add to next and merge previous and next if needed.
//			if ((j + 1) <DIGIT_CHECK_COL_PER_ROW) {
//				dtmp1 = digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j + 1];
//				// if it is not last valid piece, otherwise, skip it
//				if (fabs(dtmp1) < 0.01) continue;
//				dtmp2 = digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j + 1];
//				// add value to next
//				if (dtmp2 > 0) {
//					digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j + 1] += per1;
//				} else {
//					digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j + 1] -= per1;
//				}
//				// merge with previous value
//				if (j != 0) {
//					digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j - 1] +=
//								digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j + 1];
//					for (int k=j;k<DIGIT_CHECK_COL_PER_ROW;k++) {
//						if ((k + 2) >= DIGIT_CHECK_COL_PER_ROW) {
//							digParams.points[i * DIGIT_CHECK_COL_PER_ROW + k] = 0;
//						} else {
//							digParams.points[i * DIGIT_CHECK_COL_PER_ROW + k] =
//								digParams.points[i * DIGIT_CHECK_COL_PER_ROW + k + 2];
//						}
//					}
//				} else {
//					for (int k=j;k<DIGIT_CHECK_COL_PER_ROW;k++) {
//						if ((k + 1) >= DIGIT_CHECK_COL_PER_ROW) {
//							digParams.points[i * DIGIT_CHECK_COL_PER_ROW + k] = 0;
//						} else {
//							digParams.points[i * DIGIT_CHECK_COL_PER_ROW + k] =
//								digParams.points[i * DIGIT_CHECK_COL_PER_ROW + k + 1];
//						}
//					}
//				}
//			}
//		}
//		// calculate white weight;
//	}
	// calculate weights
	for (int i=0;i<DIGIT_CHECK_MAX_ROW && i<digParams.height;i++) {
		dtmp = 0;
		for (int j=0;j<DIGIT_CHECK_COL_PER_ROW;j++) {
			if (digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j] > 0) {
				dtmp += digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j];
			}
		}
		digParams.weights[i] = dtmp;
		// calculate white weight;
	}


	char out[300];
	out[0] = '\0';
	for (int i=0;i<DIGIT_CHECK_MAX_ROW && i<digParams.height;i++) {
		for (int j=0;j<DIGIT_CHECK_COL_PER_ROW;j++) {
			sprintf(temp, "%1.2f ", digParams.points[i * DIGIT_CHECK_COL_PER_ROW + j]);
			strcat(out, temp);
		}
		printf("%d: %s\n", i, out);
		out[0] = '\0';
	}

	di.chr = DigitUtils::FindDigit(digParams);
	return di.chr;
}

void ProcImg::FindChars(const char *filename)
{
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);

	Mat org = imread(filename, 0);

	Rect roi;
	roi.x = 370;
	roi.y = 520;
	roi.width = 1700 - roi.x;
	roi.height = 750 - roi.y;

	Mat img = org(roi);
	resize(img, img, Size(0,0), 0.4, 0.4, INTER_AREA);

	//equalizeHist(img, img);
	// this is good, can try
	GaussianBlur(img, img, cv::Size(0, 0), 3);
	addWeighted(img, 2, img, -1, 0, img);
	imwrite("before-eq.jpg", img, params);
	// good
	Mat toComp;
	medianBlur(img, img, 3);
	adaptiveThreshold(img, toComp, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 13, -1);
	imwrite("before0.jpg", toComp, params);

	Mat element = getStructuringElement(MORPH_RECT, Size(6, 6));
	morphologyEx(toComp, img, MORPH_OPEN, element);
	imwrite("before1.jpg", img, params);

	resize(toComp, toComp, Size(0,0), 0.5, 0.5, INTER_AREA);
	cv::threshold(toComp, toComp, 50, 255, CV_THRESH_BINARY);
	imwrite("before2.jpg", toComp, params);

	element = getStructuringElement(MORPH_RECT, Size(4, 4));
	morphologyEx(img, img, MORPH_CLOSE, element);
	imwrite("before3.jpg", img, params);

	resize(img, img, Size(0,0), 0.5, 0.5, INTER_AREA);
	cv::threshold(img, img, 10, 255, CV_THRESH_BINARY);

	//toComp = img;

//	adaptiveThreshold(img, img, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 11, 0);
//	medianBlur(img, img, 3);
//	Mat element = getStructuringElement(MORPH_RECT, Size(2, 2), Point(-1, -1));
//	morphologyEx(img, img, MORPH_CLOSE, element);
//	medianBlur(img, img, 3);
	imwrite("before.jpg", img, params);

	std::vector<std::vector<Point> > contours;
	findContours(img, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);
	//Mat cont;
	//cont.create(img.rows, img.cols, CV_8U);
	//drawContours(cont, contours, -1, Scalar(255,0,0), 1);
	//imwrite("beforeCt.jpg", cont, params);
	//printf("contours: %d\n", time(NULL));
	ContInfo ci;
	std::list<ContInfo> conts;
	for (int i=0;i<contours.size();i++) {
		ci.rect = boundingRect(contours[i]);
		ci.area = contourArea(contours[i]);
		printf("Filter: %d,%d,%d,%d-%d\n", ci.rect.x, ci.rect.y, ci.rect.width, ci.rect.height, ci.area);
		if (ci.rect.width > gParams.MaxCharWidth) continue;
		if (ci.rect.height > gParams.MaxCharHeight) continue;
		if (ci.rect.height <= 2 && ci.rect.width <= 2) continue;
		if (((ci.rect.width * ci.rect.height) / 10) > ci.area) {
			printf("Skip area: %d, %d\n", ((ci.rect.width * ci.rect.height) / 10) , ci.area);
			continue;
		}
		AddContInfo(conts, ci);
	}
	std::list<ContInfo>::iterator it = conts.begin(), end = conts.end();
	for (;it != end; it++) {
		printf("Cont: %d,%d,%d,%d-%d\n", ((ContInfo &)(*it)).rect.x, (*it).rect.y, (*it).rect.width, (*it).rect.height, (*it).area);
	}
	int maxWidth = 0, minWidth = 200;
	std::list<DigitInfo> digits;
	FindDigits(conts, digits, conts.begin(), conts.end(), maxWidth, minWidth);


	char temp[100];
	Mat dig;
	Rect rect;
	int index=0;
	char text[100];
	text[0] = '\0';
	int textPos = 0;
	char ch;

	int nextx = 0;
	std::list<DigitInfo>::iterator dit = digits.begin(), dend = digits.end(), nextdit;
	for (;dit != dend; dit++) {
		nextx = 5000;
		nextdit = dit;
		nextdit++;
		if (nextdit != dend) nextx = (*nextdit).rect.x;
		printf("Find char: %d, %d, %d, %d\n", (*dit).rect.x, (*dit).rect.y, (*dit).rect.width, (*dit).rect.height);
		if ((*dit).chr == 0) mpCheckChar->MatchDigit((*dit), toComp, index, minWidth, maxWidth, nextx);
		//if ((*dit).chr == 0) MatchDigit((*dit), img, index, minWidth, maxWidth, nextx);
		//if ((*dit).chr == 0) DetermineDigit((*dit), toComp, index, minWidth, maxWidth, nextx);
		else printf("had %c\n", (*dit).chr);
		ch = (*dit).chr;
		if (ch != 0) {
			text[textPos++] = ch;
			text[textPos] = '\0';
		}
		//dig = toComp((*dit).rect);
		//sprintf(temp, "get-%d.jpg", index);
		//imwrite(temp, dig, params);
		index++;
	}
	printf("Found cont: %d, digits: %d, text: %s\n", conts.size(), digits.size(), text);
//	Mat result;
//	std::list<CharInfo *> chars;
//	for (int i=0;i<MAX_CHAR_TYPE;i++) {
//		if (mpChars[i].pMat) {
//			MatchTmpl(mpChars[i].ch, img, (Mat &) (*mpChars[i].pMat), result, chars);
//		}
//	}
//	char text[110];
//	text[0] = '\0';
//	int pos = 0;
//	CharInfo *pci;
//	while(!chars.empty()) {
//		pci = chars.front();
//		if (pos < 100) {
//			text[pos++] = pci->ch;
//			text[pos] = '\0';
//		}
//		delete pci;
//		chars.pop_front();
//	}
//	printf("Find text: %s\n", text);
}
*/
/*
// good
bool ProcImg::FindABox1117(std::list<ContInfo>::iterator &nit,	std::list<ContInfo>::iterator end,
		std::list<ContInfo> &cis, Rect &outRect, int locX, int locY, int width,
		int height, bool &is1, int digitIndex)
{
	if (nit == end) return false;
	Rect rect = (*nit).rect;
	cis.clear();
	int cnt = 0;
	// cis.push_back((*nit));
	int itmp;
	for (;nit != end; nit++) {
		++cnt;
		printf("........ check: %d,%d,%d,%d\n", (*nit).rect.x, (*nit).rect.y, (*nit).rect.width, (*nit).rect.height);
		// check whether it is 1
		itmp = (*nit).rect.height - height;
		if (locX != 0 && itmp <= 5 && itmp >= -5
				&& (*nit).rect.width >= 2 && (*nit).rect.width <= 8) {
			if (cnt == 1) {
				nit++;
				printf("stop for 1\n");
				is1 = true;
				break;
			}

			// TODO??? handle 1 when it is at third digit or other digit
			bool cont = false;
			// if it is digit after third digit, "1" must be at fist or not too far from beginning
			if (cnt != 0) {
				if (((*nit).rect.x + (*nit).rect.width - locX) < 13)
					cont = true; // continue with digit 1.
			}
			// continue with digit 1 or just a piece of other digit.
			if (cont) {
				is1 = true;
				if (rect.height >= 10 || rect.width >= 10) {
					// skip first one
					if (cnt == 1) nit++;
					break;
				}
				// otherwise, skip existing pieces
				rect = (*nit).rect;
				printf("stop 1\n");
				break;
			}
		}
		// stop when next piece is much out of rectange
		if (width != 0 && ((*nit).rect.x + (*nit).rect.width - rect.x) >= (width + 5) ) {
			printf("stop 1.5\n");
			break;
		}
		// skip the piece which is not in current digit rectangle
		if (digitIndex != 2 && width != 0 && (locX + width  + 8) <= ((*nit).rect.x + (*nit).rect.width)) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 2: %d,%d,%d,%d\n", width, locX, (*nit).rect.x, (*nit).rect.width);
			break;;
		}
		// stop when piece is out of box from height
		if ((height > 0 && ((*nit).rect.y + (*nit).rect.height - locY) > (height + 5))
			|| (*nit).rect.height >= gParams.MaxCharHeight) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 3\n");
			break;
		}
		if (locY + 5 > (*nit).rect.y + (*nit).rect.height) {
			printf("skip 4\n");
			continue;
		}
		//if (locY == 0) {
		//	itmp = (*nit).rect.x + (*nit).rect.width - rect.x;
		//}
		// make sure it is not overlap with height
		//if (rect.y + 5 > ((*nit).rect.y + (*nit).rect.height))
		//	continue;
		//else break; // invalid piece between it.
		itmp = (*nit).rect.x + (*nit).rect.width - rect.x;
		if (itmp > gParams.MaxCharWidth || itmp < 0) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 5\n");
			break;
		}
		itmp = (*nit).rect.y + (*nit).rect.height - rect.y;
		if (itmp > gParams.MaxCharHeight || itmp < 0) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 6\n");
			break;
		}
		// nit.rect.y might smaller than current rect.
		itmp = (*nit).rect.y + (*nit).rect.height - (*nit).rect.y;
		if (itmp > gParams.MaxCharHeight || itmp < 0) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 7\n");
			break;
		}

		if ((*nit).rect.y < rect.y) rect.y = (*nit).rect.y;
		itmp = (*nit).rect.x + (*nit).rect.width - rect.x;
		if (itmp > rect.width) rect.width = itmp;
		itmp = (*nit).rect.y + (*nit).rect.height - rect.y;
		if (itmp > rect.height) rect.height = itmp;
		cis.push_back((*nit));
		printf("........ added\n");
	}
	//
	if (height != 0 && ((rect.height + 5) < height || (rect.height - 4) > height))
		return false;
	if ((height == 0 || (rect.height + 5 > height && (rect.height - 5) < height))
		&& rect.height >= gParams.MinCharHeight && rect.height < gParams.MaxCharHeight
		&& rect.width < gParams.MaxCharWidth && rect.width >= gParams.MinCharWidth) {
		outRect = rect;
		if (rect.width < 8 && cis.size() == 1) is1 = true;
		return true;
	}
	printf("    fail 2 : %d,%d,%d,%d,   %dx%d\n", rect.x, rect.y, rect.width, rect.height, width, height);
	return false;
}


void ProcImg::FindDigits1117(std::list<ContInfo> &conts, std::list<DigitInfo> &digits, std::list<ContInfo>::iterator it,
		std::list<ContInfo>::iterator end, int &maxWidth, int &minWidth, Mat &toComp)
{
	std::list<ContInfo> cis;
	Rect outRect;
	std::list<ContInfo>::iterator nit;
	Rect firstRect = Rect(0,0,0,0);
	int locX = 0, locY = 0, width = 0, height = 0;
	int itmp = 0;
	DigitInfo di;
	bool is1 = false;
	// find first digit
	int digitIndex = 0;
	for (;it != end;) {
		// find a cont
		printf("... finding: %d,%d,%d,%d\n", (*it).rect.x, (*it).rect.y, (*it).rect.width, (*it).rect.height);
		// find a large piece for first digit.
		if (locY == 0 && (*it).area < 30) {
			++it;
			continue;
		}
		nit = it;
		is1 = false;
		if (FindABox1117(nit, end, cis, outRect, locX, locY, width, height, is1, digitIndex)) {
			di.rect = outRect;
			di.cis = cis;
			if (is1) {
				printf("find 1\n");
				di.chr = '1';
			}
			else di.chr = 0;

			if ((digitIndex == 0 || digitIndex == 2) && !is1) {
				// it must be a valid digit
				int conf = mpCheckChar->MatchDigit1117(di, toComp, 0, minWidth, maxWidth, 5000);
				if (conf < 46) {
					// skip this letter
					printf("Skip first char for %c:%d%%", di.chr, conf);
					++it;
					continue;
				}
			}
			it = nit;
			printf("Found a box: %d,%d,%d,%d\n",
					outRect.x, outRect.y, outRect.width, outRect.height);
			if (locY == 0) {
				locY = outRect.y;
				height = outRect.height;
				width = outRect.width;
			}
			itmp = outRect.y - locY;
			// update y location because it can change (not always at same line)
			if (itmp < 5 && itmp > -5) locY = outRect.y;
			// mini x poistion for next char
			locX = outRect.x + outRect.width - 3;
			di.rect = outRect;
			di.cis = cis;
			if (is1) {
				printf("find 1\n");
				di.chr = '1';
			}
			else di.chr = 0;
			digits.push_back(di);
			if (outRect.width > maxWidth) maxWidth = outRect.width;
			if (!is1 && outRect.width < minWidth) minWidth = outRect.width;
			++digitIndex;
		} else it++;
	}
}



int ProcImg::FindChars1117(const char *filename, char *outText, int outBufSize)
{
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);

	Mat org = imread(filename, 1);

	Rect roi;
	roi.x = 370;
	roi.y = 520;
	roi.width = 1900 - roi.x;
	roi.height = 750 - roi.y;

	Mat img = org(roi);
	resize(img, img, Size(0,0), 0.4, 0.4, INTER_AREA);

	// fastNlMeansDenoisingColored()
	balance_white(img);
    cvtColor(img, img, CV_BGR2GRAY);
	imwrite("before-wb.jpg", img, params);

	//equalizeHist(img, img);
	// this is good, can try
	GaussianBlur(img, img, cv::Size(0, 0), 3);
	addWeighted(img, 2, img, -1, 0, img);
	imwrite("before-eq.jpg", img, params);
	// good
	Mat toComp;
	medianBlur(img, img, 3);
	adaptiveThreshold(img, toComp, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 13, -1);
	imwrite("before0.jpg", toComp, params);

	Mat element = getStructuringElement(MORPH_RECT, Size(6, 6));
	morphologyEx(toComp, img, MORPH_OPEN, element);
	imwrite("before1.jpg", img, params);

	resize(toComp, toComp, Size(0,0), 0.5, 0.5, INTER_AREA);
	cv::threshold(toComp, toComp, 50, 255, CV_THRESH_BINARY);
	imwrite("before2.jpg", toComp, params);

	element = getStructuringElement(MORPH_RECT, Size(4, 4));
	morphologyEx(img, img, MORPH_CLOSE, element);
	imwrite("before3.jpg", img, params);

	resize(img, img, Size(0,0), 0.5, 0.5, INTER_AREA);
	cv::threshold(img, img, 10, 255, CV_THRESH_BINARY);

	//toComp = img;

//	adaptiveThreshold(img, img, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 11, 0);
//	medianBlur(img, img, 3);
//	Mat element = getStructuringElement(MORPH_RECT, Size(2, 2), Point(-1, -1));
//	morphologyEx(img, img, MORPH_CLOSE, element);
//	medianBlur(img, img, 3);
	imwrite("before.jpg", img, params);

	std::vector<std::vector<Point> > contours;
	findContours(img, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);
	//Mat cont;
	//cont.create(img.rows, img.cols, CV_8U);
	//drawContours(cont, contours, -1, Scalar(255,0,0), 1);
	//imwrite("beforeCt.jpg", cont, params);
	//printf("contours: %d\n", time(NULL));
	ContInfo ci;
	std::list<ContInfo> conts;
	for (int i=0;i<contours.size();i++) {
		ci.rect = boundingRect(contours[i]);
		ci.area = contourArea(contours[i]);
		printf("Filter: %d,%d,%d,%d-%d\n", ci.rect.x, ci.rect.y, ci.rect.width, ci.rect.height, ci.area);
		if (ci.rect.width > gParams.MaxCharWidth) continue;
		if (ci.rect.height > gParams.MaxCharHeight) continue;
		if (ci.rect.height <= 2 && ci.rect.width <= 2) continue;
		if (((ci.rect.width * ci.rect.height) / 10) > ci.area) {
			printf("Skip area: %d, %d\n", ((ci.rect.width * ci.rect.height) / 10) , ci.area);
			continue;
		}
		AddContInfo(conts, ci);
	}
	std::list<ContInfo>::iterator it = conts.begin(), end = conts.end();
	for (;it != end; it++) {
		printf("Cont: %d,%d,%d,%d-%d\n", (*it).rect.x, (*it).rect.y, (*it).rect.width, (*it).rect.height, (*it).area);
	}
	int maxWidth = 0, minWidth = 200;
	std::list<DigitInfo> digits;
	FindDigits1117(conts, digits, conts.begin(), conts.end(), maxWidth, minWidth, toComp);


	char temp[100];
	Mat dig;
	Rect rect;
	int index=0;
	char text[100];
	text[0] = '\0';
	int textPos = 0;
	char ch;

	int nextx = 0;
	std::list<DigitInfo>::iterator dit = digits.begin(), dend = digits.end(), nextdit;
	for (;dit != dend; dit++) {
		nextx = 5000;
		nextdit = dit;
		nextdit++;
		if (nextdit != dend) nextx = (*nextdit).rect.x;
		printf("Find char: %d, %d, %d, %d\n", (*dit).rect.x, (*dit).rect.y, (*dit).rect.width, (*dit).rect.height);
		if ((*dit).chr == 0) mpCheckChar->MatchDigit1117((*dit), toComp, index, minWidth, maxWidth, nextx);
		//if ((*dit).chr == 0) MatchDigit((*dit), img, index, minWidth, maxWidth, nextx);
		//if ((*dit).chr == 0) DetermineDigit((*dit), toComp, index, minWidth, maxWidth, nextx);
		else printf("had %c\n", (*dit).chr);
		ch = (*dit).chr;
		if (ch != 0) {
			text[textPos++] = ch;
			text[textPos] = '\0';
		}
		//dig = toComp((*dit).rect);
		//sprintf(temp, "get-%d.jpg", index);
		//imwrite(temp, dig, params);
		index++;
	}
	dit = digits.begin(), dend = digits.end();

	// check text position
	index = 0;
	textPos = 0;
	text[0] = '\0';
	for (;dit != dend; dit++) {
		text[index] = (*dit).chr;
		++index;
		text[index] = '\0';
		printf("verify: %d - %d,%d\n", nextx, (*dit).rect.x, (*dit).rect.width);
		if (index == 1) {
			nextx = (*dit).rect.x + (*dit).rect.width;
			continue;
		}
		if ((*dit).rect.x > (nextx + 15)) {
			if (index == 3) {
				nextx = (*dit).rect.x + (*dit).rect.width;
				continue;
			}
			// last digit is not correct
			if (index == 4) {
				printf("Remove 3rd char: %c, %d\n", text[2], nextx);
				text[index - 2] = (*dit).chr;
				text[index -1] = '\0';
				index = 3;
				nextx = (*dit).rect.x + (*dit).rect.width;
				continue;
			}
		}
		nextx = (*dit).rect.x + (*dit).rect.width;
	}
	printf("Found cont: %d, digits: %d, text: %s\n", conts.size(), digits.size(), text);
	int len = strlen(text);
	outText[0] = '\0';
	for (int i=0;i<len && i<outBufSize;i++) {
		outText[i] = text[i];
		outText[i+1] = '\0';
	}
	return strlen(outText);
}
*/

/*
// 2018.11.16, very good
void ProcImg::FindChars(const char *filename)
{
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);

	Mat org = imread(filename, 0);

	Rect roi;
	roi.x = 370;
	roi.y = 520;
	roi.width = 1700 - roi.x;
	roi.height = 750 - roi.y;

	Mat img = org(roi);
	resize(img, img, Size(0,0), 0.4, 0.4, INTER_AREA);
	// good
	Mat toComp;
	medianBlur(img, img, 3);
	adaptiveThreshold(img, toComp, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 13, -1);
	imwrite("before0.jpg", toComp, params);

	Mat element = getStructuringElement(MORPH_RECT, Size(6, 6));
	morphologyEx(toComp, img, MORPH_OPEN, element);
	imwrite("before1.jpg", img, params);

	resize(toComp, toComp, Size(0,0), 0.5, 0.5, INTER_AREA);
	cv::threshold(toComp, toComp, 50, 255, CV_THRESH_BINARY);
	imwrite("before2.jpg", toComp, params);

	element = getStructuringElement(MORPH_RECT, Size(4, 4));
	morphologyEx(img, img, MORPH_CLOSE, element);
	imwrite("before3.jpg", img, params);

	resize(img, img, Size(0,0), 0.5, 0.5, INTER_AREA);
	cv::threshold(img, img, 10, 255, CV_THRESH_BINARY);

	//toComp = img;

//	adaptiveThreshold(img, img, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 11, 0);
//	medianBlur(img, img, 3);
//	Mat element = getStructuringElement(MORPH_RECT, Size(2, 2), Point(-1, -1));
//	morphologyEx(img, img, MORPH_CLOSE, element);
//	medianBlur(img, img, 3);
	imwrite("before.jpg", img, params);

	std::vector<std::vector<Point> > contours;
	findContours(img, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);
	//Mat cont;
	//cont.create(img.rows, img.cols, CV_8U);
	//drawContours(cont, contours, -1, Scalar(255,0,0), 1);
	//imwrite("beforeCt.jpg", cont, params);
	//printf("contours: %d\n", time(NULL));
	ContInfo ci;
	std::list<ContInfo> conts;
	for (int i=0;i<contours.size();i++) {
		ci.rect = boundingRect(contours[i]);
		ci.area = contourArea(contours[i]);
		printf("Filter: %d,%d,%d,%d-%d\n", ci.rect.x, ci.rect.y, ci.rect.width, ci.rect.height, ci.area);
		if (ci.rect.width > gParams.MaxCharWidth) continue;
		if (ci.rect.height > gParams.MaxCharHeight) continue;
		if (ci.rect.height <= 2 && ci.rect.width <= 2) continue;
		if (((ci.rect.width * ci.rect.height) / 10) > ci.area) {
			printf("Skip area: %d, %d\n", ((ci.rect.width * ci.rect.height) / 10) , ci.area);
			continue;
		}
		AddContInfo(conts, ci);
	}
	std::list<ContInfo>::iterator it = conts.begin(), end = conts.end();
	for (;it != end; it++) {
		printf("Cont: %d,%d,%d,%d-%d\n", (*it).rect.x, (*it).rect.y, (*it).rect.width, (*it).rect.height, (*it).area);
	}
	int maxWidth = 0, minWidth = 200;
	std::list<DigitInfo> digits;
	FindDigits(conts, digits, conts.begin(), conts.end(), maxWidth, minWidth);


	char temp[100];
	Mat dig;
	Rect rect;
	int index=0;
	char text[100];
	text[0] = '\0';
	int textPos = 0;
	char ch;

	int nextx = 0;
	std::list<DigitInfo>::iterator dit = digits.begin(), dend = digits.end(), nextdit;
	for (;dit != dend; dit++) {
		nextx = 5000;
		nextdit = dit;
		nextdit++;
		if (nextdit != dend) nextx = (*nextdit).rect.x;
		printf("Find char: %d, %d, %d, %d\n", (*dit).rect.x, (*dit).rect.y, (*dit).rect.width, (*dit).rect.height);
		if ((*dit).chr == 0) MatchDigit((*dit), toComp, index, minWidth, maxWidth, nextx);
		//if ((*dit).chr == 0) MatchDigit((*dit), img, index, minWidth, maxWidth, nextx);
		//if ((*dit).chr == 0) DetermineDigit((*dit), toComp, index, minWidth, maxWidth, nextx);
		else printf("had %c\n", (*dit).chr);
		ch = (*dit).chr;
		if (ch != 0) {
			text[textPos++] = ch;
			text[textPos] = '\0';
		}
		//dig = toComp((*dit).rect);
		//sprintf(temp, "get-%d.jpg", index);
		//imwrite(temp, dig, params);
		index++;
	}
	printf("Found cont: %d, digits: %d, text: %s\n", conts.size(), digits.size(), text);
//	Mat result;
//	std::list<CharInfo *> chars;
//	for (int i=0;i<MAX_CHAR_TYPE;i++) {
//		if (mpChars[i].pMat) {
//			MatchTmpl(mpChars[i].ch, img, (Mat &) (*mpChars[i].pMat), result, chars);
//		}
//	}
//	char text[110];
//	text[0] = '\0';
//	int pos = 0;
//	CharInfo *pci;
//	while(!chars.empty()) {
//		pci = chars.front();
//		if (pos < 100) {
//			text[pos++] = pci->ch;
//			text[pos] = '\0';
//		}
//		delete pci;
//		chars.pop_front();
//	}
//	printf("Find text: %s\n", text);
}
*/

/*
void ProcImg::FindChars(const char *filename)
{
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);

	Mat org = imread(filename, 0);

	Rect roi;
	roi.x = 420;
	roi.y = 520;
	roi.width = 1700 - 420;
	roi.height = 750 - 520;

	Mat img = org(roi);
	resize(img, img, Size(0,0), 0.4, 0.4, INTER_AREA);
	// good
	Mat toComp;
	medianBlur(img, img, 3);
	adaptiveThreshold(img, toComp, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 13, -1);

	Mat element = getStructuringElement(MORPH_RECT, Size(6, 6));
	morphologyEx(toComp, img, MORPH_OPEN, element);
	imwrite("before1.jpg", img, params);

	resize(img, toComp, Size(0,0), 0.5, 0.5, INTER_AREA);
	//element = getStructuringElement(MORPH_RECT, Size(3, 3));
	//morphologyEx(toComp, toComp, MORPH_CLOSE, element);
	//adaptiveThreshold(toComp, toComp, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 5, -1);
	imwrite("before2.jpg", toComp, params);

	element = getStructuringElement(MORPH_RECT, Size(6, 6));
	morphologyEx(img, img, MORPH_CLOSE, element);
	imwrite("before3.jpg", img, params);
	resize(img, img, Size(0,0), 0.5, 0.5, INTER_AREA);
	//element = getStructuringElement(MORPH_RECT, Size(4, 4));
	//morphologyEx(img, img, MORPH_CLOSE, element);
	//imwrite("before4.jpg", img, params);
	//adaptiveThreshold(img, img, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 5, -1);



//	adaptiveThreshold(img, img, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 11, 0);
//	medianBlur(img, img, 3);
//	Mat element = getStructuringElement(MORPH_RECT, Size(2, 2), Point(-1, -1));
//	morphologyEx(img, img, MORPH_CLOSE, element);
//	medianBlur(img, img, 3);
	imwrite("before.jpg", img, params);

	std::vector<std::vector<Point> > contours;
	findContours(img, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);
	//Mat cont;
	//cont.create(img.rows, img.cols, CV_8U);
	//drawContours(cont, contours, -1, Scalar(255,0,0), 1);
	//imwrite("beforeCt.jpg", cont, params);
	//printf("contours: %d\n", time(NULL));
	ContInfo ci;
	std::list<ContInfo> conts;
	for (int i=0;i<contours.size();i++) {
		ci.rect = boundingRect(contours[i]);
		ci.area = contourArea(contours[i]);
		//printf("Cont: %d,%d,%d,%d-%d\n", ci.rect.x, ci.rect.y, ci.rect.width, ci.rect.height, ci.area);
		if (ci.rect.width > 30) continue;
		if (ci.rect.height > 40) continue;
		if (ci.rect.height <= 2 && ci.rect.width <= 2) continue;
		if (((ci.rect.width * ci.rect.height) / 10) > ci.area)
			continue;
		AddContInfo(conts, ci);
	}
	std::list<ContInfo>::iterator it = conts.begin(), end = conts.end();
	for (;it != end; it++) {
		printf("Cont: %d,%d,%d,%d-%d\n", (*it).rect.x, (*it).rect.y, (*it).rect.width, (*it).rect.height, (*it).area);
	}
	std::list<DigitInfo> digits;
	FindDigits(conts, digits, conts.begin(), conts.end());

	std::list<DigitInfo>::iterator dit = digits.begin(), dend = digits.end();

	char temp[100];
	Mat dig;
	Rect rect;
	int i=0;
	for (;dit != dend; dit++) {
		dig = toComp((*dit).rect);
		sprintf(temp, "get-%d.jpg", i++);
		imwrite(temp, dig, params);
	}
	printf("Found cont: %d, digits: %d\n", conts.size(), digits.size());
//	Mat result;
//	std::list<CharInfo *> chars;
//	for (int i=0;i<MAX_CHAR_TYPE;i++) {
//		if (mpChars[i].pMat) {
//			MatchTmpl(mpChars[i].ch, img, (Mat &) (*mpChars[i].pMat), result, chars);
//		}
//	}
//	char text[110];
//	text[0] = '\0';
//	int pos = 0;
//	CharInfo *pci;
//	while(!chars.empty()) {
//		pci = chars.front();
//		if (pos < 100) {
//			text[pos++] = pci->ch;
//			text[pos] = '\0';
//		}
//		delete pci;
//		chars.pop_front();
//	}
//	printf("Find text: %s\n", text);
}
*/

int ProcImg::ProcessImage(const char *filename, char *text, int bufSize)
{
	//FindChars(filename);
	//return FindChars1117(filename, text, bufSize);
	try {
		text[0] = '\0';
		return mImgProc.FindChars(filename, text, bufSize);
	} catch (cv::Exception &exp) {
		printf("Caught exception %s\n", exp.msg.c_str());
		return 0;
	}
}

