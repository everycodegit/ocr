/*
 * ImageProc.hpp
 *
 *  Created on: Nov 18, 2018
 *      Author: peter1
 */

#ifndef IMAGEPROC1_HPP_
#define IMAGEPROC1_HPP_

#include "ProcTypes.hpp"
#include "checkChar.hpp"

class ImageProc1
{
private:
	CheckChar			*mpCheckChar;
public:
						ImageProc1			();
						~ImageProc1			();
	bool				FindABox			(std::list<ContInfo>::iterator &nit, std::list<ContInfo>::iterator end,
												std::list<ContInfo> &cis, Rect &outRect, int locX, int locY, int width,
												int height, bool &is1, int digitIndex);
	void 				FindDigits			(std::list<ContInfo> &conts, std::list<DigitInfo> &digits, std::list<ContInfo>::iterator it,
												std::list<ContInfo>::iterator end, int &maxWidth, int &minWidth, Mat &toComp);
	int					FindChars			(const char *filename, char *outText, int outBufSize);

private:
	void 				BalanceWhite		(cv::Mat &mat);
	void 				AddContInfo			(std::list<ContInfo> &cis, const ContInfo &ci);

};



#endif /* IMAGEPROC1_HPP_ */
