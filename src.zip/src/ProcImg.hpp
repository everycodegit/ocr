/*
 * ProcImg.hpp
 *
 *  Created on: Nov 7, 2018
 *      Author: peter1
 */

#ifndef PROCIMG_HPP_
#define PROCIMG_HPP_

#include "ProcTypes.hpp"
#include "CheckChar.hpp"
#include "ImageProc.hpp"
#include "ImageProc1.hpp"


class ProcImg
{
private:
	// CheckChar			*mpCheckChar;
	ImageProc1			mImgProc;
public:
						ProcImg					();
						~ProcImg				();

	int					ProcessImage			(const char *filename, char *text, int bufSize);
private:
	void				LoadChars				();
	void				FindChars				(const char *filename);
	void				MatchTmpl				(char chr, Mat &img, Mat &tmpl, Mat &result, std::list<CharInfo*> &chars);
	bool 				MatchDigit				(DigitInfo &di, Mat &org, int index, int minWidth, int maxWidth, int nextX);
	bool 				DetermineDigit			(DigitInfo &di, Mat &org, int index, int minWidth, int maxWidth, int nextX);

	void 				FindDigits				(std::list<ContInfo> &conts, std::list<DigitInfo> &digits, std::list<ContInfo>::iterator it,
												std::list<ContInfo>::iterator end, int &maxWidth, int &minWidth);

	bool				FindABox1117			(std::list<ContInfo>::iterator &nit, std::list<ContInfo>::iterator end,
												std::list<ContInfo> &cis, Rect &outRect, int locX, int locY, int width,
												int height, bool &is1, int digitIndex);
	void 				FindDigits1117			(std::list<ContInfo> &conts, std::list<DigitInfo> &digits, std::list<ContInfo>::iterator it,
												std::list<ContInfo>::iterator end, int &maxWidth, int &minWidth, Mat &toComp);
	int					FindChars1117			(const char *filename, char *outText, int outBufSize);
};



#endif /* PROCIMG_HPP_ */
