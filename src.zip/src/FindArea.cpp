/*
 * FindArea.cpp
 *
 *  Created on: Dec 3, 2018
 *      Author: peter1
 */

#include "FindArea.hpp"

FindArea::FindArea()
{
	mMaxBlobDist = 6;
}

void FindArea::FindArea::RemoveIsolatedBlob(vector<vector<Point>> contours, vector<vector<Point>> &newCont)
{
	int maxDist = 4;
	Rect rect, rect1;
	float area, area1, totalarea, fdist;
	Point p1, p2;
	int itmp;
	for (int i=0;i<contours.size();i++) {
		rect = boundingRect(contours[i]);
		area = contourArea(contours[i]);
		if (area < 3) {
			totalarea = area;
			bool surrounded = false;
			for (int j=0;j<contours.size();j++) {
				// skip itself
				if (j == i) continue;
				rect1 = boundingRect(contours[j]);
				area1 = contourArea(contours[j]);
				if ((rect & rect1).area() > 0) {
					continue;
				}
				p1 = Point(rect1.x + rect1.width / 2, rect1.y + rect1.height / 2 );
				p2 = Point(rect.x + rect.width / 2, rect.y + rect.height / 2);
				if (rect.x == rect1.x) {
					p1.x = rect.x;
					p2.x = p1.x;
				} else {
					itmp = (rect1.x - rect.x) / abs(rect1.x - rect.x);
					p1.x += itmp * rect1.width / 2;
					p2.x -= itmp * rect.width / 2;
				}
				if (rect1.y == rect.y) {
					p1.y = rect.y;
					p2.y = p1.y;
				} else {
					itmp = (rect1.y - rect.y) / abs(rect1.y - rect.y);
					p1.y += itmp * rect1.height / 2;
					p2.y -= itmp * rect.height / 2;
				}
				fdist = fabs(norm(p1 - p2));
				if (fdist < maxDist) {
					// keep it
					surrounded = true;
					break;
				}
			}
			if (surrounded) {
				newCont.push_back(contours[i]);
			}
		} else {
			newCont.push_back(contours[i]);
		}
	}
}

int FindArea::rectDistance(Rect &rect, Rect &rect1)
{
	if ((rect & rect1).area() > 0) {
		return 0;
	}
	Point p1,p2;
	int x1 = rect.x, x2 = rect.x + rect.width;
	int x3 = rect1.x, x4 = rect1.x + rect1.width;
	if (x1 == x3) {
		p1.x = x1;
		p2.x = x1;
	} else if (x1 > x3) {
		if (x1 > x4) {
			p1.x = x1;
			p2.x = x3;
		} else {
			// overlapped
			p1.x = x2;
			p2.x = x2;
		}
	} else {
		// x1 < x3
		if (x3 > x2) {
			p1.x = x2;
			p2.x = x4;
		} else {
			// overlap
			p1.x = x2;
			p2.x = x2;
		}
	}
	int y1 = rect.y, y2 = rect.y + rect.height;
	int y3 = rect1.y, y4 = rect1.y + rect1.height;
	if (y1 == y3) {
		p1.y = y1;
		p2.y = y1;
	} else if (y1 > y3) {
		if (y1 > y4) {
			p1.y = y1;
			p2.y = y3;
		} else {
			// overlapped
			p1.y = y2;
			p2.y = y2;
		}
	} else {
		// y1 < y3
		if (y3 > y2) {
			p1.y = y2;
			p2.y = y4;
		} else {
			// overlap
			p1.y = y2;
			p2.y = y2;
		}
	}
	int dis = fabs(norm(p1 - p2));
	return dis;
}

bool FindArea::AddCloseBlob(Rect &rect, vector<vector<Point>> &contours)
{
	vector<vector<Point>> newCont;
	bool merged = false;
	Rect rect1;
	bool added;
	for (int i=0;i<contours.size();i++) {
		added = false;
		rect1 = boundingRect(contours[i]);
		if ((rect & rect1).area() > 0) {
			added = true;
		} else if (rectDistance(rect, rect1) < mMaxBlobDist) {
			added = true;
		}
		if (added) {
			rect = rect | rect1;
			merged = true;
		} else {
			newCont.push_back(contours[i]);
		}
	}
	contours = newCont;
	return merged;
}

bool FindArea::MergeRect(vector<Rect> &rects)
{
	Rect rect;
	vector<Rect> newRects;
	for (int i=0;i<rects.size();i++) {
		if (rects[i].width == 0) continue;
		for (int j=0;j<rects.size();j++) {
			if (i == j) continue;
			if (rects[j].width == 0) continue;
			if ((rects[i] & rects[j]).area() > 0) {
				rects[i] = rects[i] | rects[j];
				rects[j].width = 0;
			} else {
				int dist = rects[j].x - rects[i].x - rects[i].width;
				if (dist >= 0) {
					if (dist < mMaxBlobDist) {
						rects[i] = rects[i] | rects[j];
						rects[j].width = 0;
					}
				} else {
					if ((rects[i].x - rects[j].x - rects[j].width) < mMaxBlobDist) {
						rects[i] = rects[i] | rects[j];
						rects[j].width = 0;
					}
				}
			}
		}
	}
	return true;
}


void FindArea::RemoveExtraRect(Rect &rect, Mat &img, int seqno)
{
	uchar *p, *pEnd;
	int count[10];
	bool first = true;
	int minRows = 3;
	int itmp;
	int maxWeight = 1;
	if (seqno > 0) maxWeight = 5;
	Rect newRect = rect;
	// remove top
	for (int i=0;i<rect.height;i++) {
		if (first) {
			for (int j=0;j<minRows;j++) {
				count[j] = 0;
				p = img.ptr(j + i + rect.y);
				p += rect.x;
				pEnd = p + rect.width;
				while(p != pEnd) {
					if (*p++ != 0) ++count[j];
				}
			}
		} else {
			memmove(count, count + 1, 9 * sizeof(int));
			itmp = minRows - 1;
			count[itmp] = 0;
			p = img.ptr(i + rect.y + minRows -1);
			p += rect.x;
			pEnd = p + rect.width;
			while(p != pEnd) {
				if (*p++ != 0) ++count[itmp];
			}
		}
		itmp = 0;
		for (int j=0;j<minRows;j++) {
			itmp += count[j];
		}
		if (itmp < maxWeight) {
			++newRect.y;
			--newRect.height;
		} else break;
	}
	// remove bottom
	first = true;
	for (int i=rect.height-1;i>=0;i--) {
		if (first) {
			for (int j=0;j<minRows;j++) {
				count[j] = 0;
				p = img.ptr(i + rect.y - j);
				p += rect.x;
				pEnd = p + rect.width;
				while(p != pEnd) {
					if (*p++ != 0) ++count[j];
				}
			}
		} else {
			memmove(count, count + 1, 9 * sizeof(int));
			itmp = minRows - 1;
			count[itmp] = 0;
			p = img.ptr(rect.y + i - minRows + 1);
			// o nly calculate selected area
			p += rect.x;
			pEnd = p + rect.width;
			while(p != pEnd) {
				if (*p++ != 0) ++count[itmp];
			}
		}
		itmp = 0;
		for (int j=0;j<minRows;j++) {
			itmp += count[j];
		}
		if (itmp < maxWeight) {
			--newRect.height;
		} else break;
	}
	rect = newRect;
}

void FindArea::FixRect(vector<Rect> &rects, Mat &img)
{
	for (int i=0;i<rects.size();i++) {
		RemoveExtraRect(rects[i], img, i);
	}
}

void FindArea::FindBlob(Mat &toUse, Mat &org, Rect &area1Rect, Rect area2Rect)
{
	SimpleBlobDetector::Params sparam;
	sparam.minDistBetweenBlobs = 1;
	sparam.minArea = 1;
	sparam.maxArea = 1000;
	sparam.filterByArea = true;
	sparam.filterByColor = false;
	sparam.filterByCircularity = false;
	sparam.filterByConvexity = false;
	sparam.filterByInertia = false;
	Ptr<SimpleBlobDetector> det = SimpleBlobDetector::create(sparam);
	vector<KeyPoint> keyps;
	det->detect(toUse, keyps);

	vector<vector<Point>> contours, newCont;
	findContours(toUse, contours, CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE);
	RemoveIsolatedBlob(contours, newCont);

	vector<Rect> rects;
	Rect rect;
	for (int i=0;i<keyps.size();i++) {
		rect.x = keyps[i].pt.x - keyps[i].size / 2;
		if (rect.x < 0) rect.x = 0;
		rect.y = keyps[i].pt.y - 3;
		if (rect.y < 0) rect.y = 0;
		rect.width = keyps[i].size / 2 + 1;
		rect.height = 6;
		int loop = 0;
		while(AddCloseBlob(rect, contours)) {
			if (++loop > 100) break;
		}
		rects.push_back(rect);
	}
	// merge rect if they are close
	MergeRect(rects);
	// remove empty rect and sort by x
	vector<Rect> newRects;
	for (int i=0;i<rects.size();i++) {
		if (rects[i].width > 0) {
			bool found = false;
			for (int j=0;j<newRects.size();j++) {
				if (rects[i].x <= newRects[j].x) {
					newRects.insert(newRects.begin() + j, rects[i]);
					found = true;
					break;
				}
			}
			if (!found) {
				newRects.push_back(rects[i]);
			}
		}
	}
	rects = newRects;
	FixRect(rects, toUse);
	//char temp[100];
	int index = 0;
	for (int i=0;i<rects.size();i++) {
		if (rects[i].width == 0) continue;
		//sprintf(temp, "/temp/outd-%d.jpg", index++);
		rect = rects[i];
		rect.x *= 20;
		rect.y *= 20;
		rect.width *= 20;
		rect.height *= 20;
		rect.x -= 30;
		rect.y -= 30;
		rect.width += 60;
		rect.height += 60;
		if (rect.x < 0) rect.x = 0;
		if (rect.y < 0) rect.y = 0;
		if ((rect.x + rect.width) > org.cols) rect.width = org.cols - rect.x;
		if ((rect.y + rect.height) > org.rows) rect.height = org.rows - rect.y;
		// imwrite(temp, org(rect));
		if (i == 0) area1Rect = rect;
		else if (i == 1) area2Rect = rect;
	}
}

int FindArea::ReprcImageTest(Mat &img, Mat &out, int vopen, int vclose)
{
	Mat element = getStructuringElement(MORPH_RECT, Size(vopen, vopen));
	morphologyEx(img, out, MORPH_OPEN, element);
	element = getStructuringElement(MORPH_RECT, Size(vclose, vclose));
	morphologyEx(img, img, MORPH_CLOSE, element);
	vector<vector<Point>> contours;
	findContours(out, contours, CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE);
	return contours.size();
}

void FindArea::ReprcImage(Mat &img, int index)
{
	int vopen = 9, vlcose = 7;
	vector<int> params;
	params.push_back(1);
	params.push_back(95);
	int blk = img.cols - 20;
	medianBlur(img, img, 3);
	adaptiveThreshold(img, img, 255, CV_ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 11, 0); // CHECK IT
	imwrite("prc-rp0.jpg", img, params);
	Mat out1, out2, out3;
	int piece1, piece2, piece3;
	piece1 = ReprcImageTest(img, out1, 7, 5);
	imwrite("prc-rp01.jpg", out1, params);
	piece2 = ReprcImageTest(img, out1, 8, 6);
	imwrite("prc-rp02.jpg", out1, params);
	piece3 = ReprcImageTest(img, out1, 9, 7);
	imwrite("prc-rp03.jpg", out1, params);
	if (index == 0) {
		if (piece1 <= 10) img = out1;
		else if (piece2 <= 10) img = out2;
		else if (piece3 <= 10) img = out3;
		else img = out2;
	} else {
		if (piece1 <= 25) img = out1;
		else if (piece2 <= 25) img = out2;
		else if (piece3 <= 25) img = out3;
		else img = out2;
	}
}

/** img should be gray, only portion that contains text, not whole image.. */
bool FindArea::FindTextArea(Mat &img, Mat &area1, Mat &area2, Rect &area1Rect, Rect &area2Rect)
{
	vector<int> params;
	params.push_back(1);
	params.push_back(95);
	Mat element;
	Mat toUse;
	adaptiveThreshold(img, toUse, 255, CV_ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 15, 0);
	element = getStructuringElement(MORPH_RECT, Size(10, 2));
	Mat toUse1;
	morphologyEx(toUse, toUse1, MORPH_OPEN, element);
	element = getStructuringElement(MORPH_RECT, Size(2, 10));
	morphologyEx(toUse, toUse1, MORPH_OPEN, element);
	imwrite("prc-use.jpg", toUse, params);
	imwrite("prc-use1.jpg", toUse1, params);
	bitwise_and(toUse, toUse1, toUse);
	imwrite("prc-usef.jpg", toUse1, params);
	element = getStructuringElement(MORPH_RECT, Size(11, 11));
	morphologyEx(toUse, toUse1, MORPH_OPEN, element);
	// drawArea
	imwrite("prc-useo.jpg", toUse1, params);
	element = getStructuringElement(MORPH_RECT, Size(40, 70));
	morphologyEx(toUse, toUse1, MORPH_CLOSE, element);
	imwrite("prc-usec.jpg", toUse1, params);
	resize(toUse, toUse, Size(0,0), 0.05, 0.05, INTER_LINEAR);
	threshold(toUse, toUse, 3, 255, 0);
	imwrite("prc-res.jpg", toUse1, params);
	FindBlob(toUse, img, area1Rect, area2Rect);
	area1 = img(area1Rect);
	area2 = img(area2Rect);
	ReprcImage(area1, 0);
	ReprcImage(area2, 1);
}
