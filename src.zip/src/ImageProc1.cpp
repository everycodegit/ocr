/*
 * ImageProc.cpp
 *
 *  Created on: Nov 18, 2018
 *      Author: peter1
 */

#include "ImageProc1.hpp"

extern ProcParams gParams;

#define RESIZE_TYPE 	INTER_LINEAR

ImageProc1::ImageProc1()
{
	mpCheckChar = new CheckChar();
}

ImageProc1::~ImageProc1()
{
	delete mpCheckChar;
}

void ImageProc1::BalanceWhite(cv::Mat &mat) {
  double discard_ratio = 0.05;
  int hists[3][256];
  memset(hists, 0, 3*256*sizeof(int));

  for (int y = 0; y < mat.rows; ++y) {
    uchar* ptr = mat.ptr<uchar>(y);
    for (int x = 0; x < mat.cols; ++x) {
      for (int j = 0; j < 3; ++j) {
        hists[j][ptr[x * 3 + j]] += 1;
      }
    }
  }

  // cumulative hist
  int total = mat.cols*mat.rows;
  int vmin[3], vmax[3];
  for (int i = 0; i < 3; ++i) {
    for (int j = 0; j < 255; ++j) {
      hists[i][j + 1] += hists[i][j];
    }
    vmin[i] = 0;
    vmax[i] = 255;
    while (hists[i][vmin[i]] < discard_ratio * total)
      vmin[i] += 1;
    while (hists[i][vmax[i]] > (1 - discard_ratio) * total)
      vmax[i] -= 1;
    if (vmax[i] < 255 - 1)
      vmax[i] += 1;
  }


  for (int y = 0; y < mat.rows; ++y) {
    uchar* ptr = mat.ptr<uchar>(y);
    for (int x = 0; x < mat.cols; ++x) {
      for (int j = 0; j < 3; ++j) {
        int val = ptr[x * 3 + j];
        if (val < vmin[j])
          val = vmin[j];
        if (val > vmax[j])
          val = vmax[j];
        ptr[x * 3 + j] = static_cast<uchar>((val - vmin[j]) * 255.0 / (vmax[j] - vmin[j]));
      }
    }
  }
}

/** add ContInfo in sequence by its X and Y, sequence from left to right, then top bottom. */
void ImageProc1::AddContInfo(std::list<ContInfo> &cis, const ContInfo &ci)
{
	std::list<ContInfo>::iterator it = cis.begin(), end = cis.end();
	bool found = false;
	for (;it != end; it++) {
		if (ci.rect.x < ((ContInfo &)(*it)).rect.x
				|| (ci.rect.x == ((ContInfo &)(*it)).rect.x && ci.rect.y < ((ContInfo &)(*it)).rect.y)) {
			found = true;
			cis.insert(it, ci);
			break;
		}
	}
	if (!found) {
		cis.push_back(ci);
	}
}

int ImageProc1::FindChars(const char *filename, char *outText, int outBufSize)
{
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);

	Mat org = imread(filename, 1);

	Rect roi;
	roi.x = 370;
	roi.y = 520;
	roi.width = 1900 - roi.x;
	roi.height = 750 - roi.y;

	Mat img = org(roi);
	resize(img, img, Size(0,0), 0.4, 0.4, RESIZE_TYPE);

	// fastNlMeansDenoisingColored()
	BalanceWhite(img);
    cvtColor(img, img, CV_BGR2GRAY);
	imwrite("before-wb.jpg", img, params);

	//equalizeHist(img, img);
	// this is good, can try
	GaussianBlur(img, img, cv::Size(0, 0), 3);
	addWeighted(img, 2, img, -1, 0, img);
	imwrite("before-eq.jpg", img, params);
	// good
	Mat toComp;
	medianBlur(img, img, 3);
	adaptiveThreshold(img, toComp, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 13, -1);
	imwrite("before0.jpg", toComp, params);

	Mat element = getStructuringElement(MORPH_RECT, Size(6, 6));
	morphologyEx(toComp, img, MORPH_OPEN, element);
	imwrite("before1.jpg", img, params);

	resize(toComp, toComp, Size(0,0), 0.5, 0.5, RESIZE_TYPE);
	cv::threshold(toComp, toComp, 50, 255, CV_THRESH_BINARY);
	imwrite("before2.jpg", toComp, params);

	element = getStructuringElement(MORPH_RECT, Size(4, 4));
	morphologyEx(img, img, MORPH_CLOSE, element);
	imwrite("before3.jpg", img, params);

	resize(img, img, Size(0,0), 0.5, 0.5, RESIZE_TYPE);

	element = getStructuringElement(MORPH_ELLIPSE, Size(1, 1));
	erode(img, img, element);
	cv::threshold(img, img, 10, 255, CV_THRESH_BINARY);


	//toComp = img;

//	adaptiveThreshold(img, img, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 11, 0);
//	medianBlur(img, img, 3);
//	Mat element = getStructuringElement(MORPH_RECT, Size(2, 2), Point(-1, -1));
//	morphologyEx(img, img, MORPH_CLOSE, element);
//	medianBlur(img, img, 3);

	imwrite("before.jpg", img, params);

	std::vector<std::vector<Point> > contours;
	findContours(img, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);
	//Mat cont;
	//cont.create(img.rows, img.cols, CV_8U);
	//drawContours(cont, contours, -1, Scalar(255,0,0), 1);
	//imwrite("beforeCt.jpg", cont, params);
	//printf("contours: %d\n", time(NULL));
	ContInfo ci;
	std::list<ContInfo> conts;
	for (int i=0;i<contours.size();i++) {
		ci.rect = boundingRect(contours[i]);
		ci.area = contourArea(contours[i]);
		printf("Filter: %d,%d,%d,%d-%d\n", ci.rect.x, ci.rect.y, ci.rect.width, ci.rect.height, ci.area);
		if (ci.rect.width > gParams.MaxCharWidth) continue;
		if (ci.rect.height > gParams.MaxCharHeight) continue;
		if (ci.rect.height <= 2 && ci.rect.width <= 2) continue;
		if (((ci.rect.width * ci.rect.height) / 10) > ci.area) {
			printf("Skip area: %d, %d\n", ((ci.rect.width * ci.rect.height) / 10) , ci.area);
			continue;
		}
		AddContInfo(conts, ci);
	}
	std::list<ContInfo>::iterator it = conts.begin(), end = conts.end();
	for (;it != end; it++) {
		printf("Cont: %d,%d,%d,%d-%d\n", ((ContInfo &)(*it)).rect.x,
				((ContInfo &)(*it)).rect.y, ((ContInfo &)(*it)).rect.width,
				((ContInfo &)(*it)).rect.height, ((ContInfo &)(*it)).area);
	}
	int maxWidth = 0, minWidth = 200;
	std::list<DigitInfo> digits;
	FindDigits(conts, digits, conts.begin(), conts.end(), maxWidth, minWidth, toComp);


	char temp[100];
	Mat dig;
	Rect rect;
	int index=0;
	char text[100];
	text[0] = '\0';
	int textPos = 0;
	char ch;

	/*
	element = getStructuringElement(MORPH_ELLIPSE, Size(3, 3));
	erode(img, toComp, element);
	imwrite("beforeMatch.jpg", toComp, params);
	*/


	int nextx = 0;
	std::list<DigitInfo>::iterator dit = digits.begin(), dend = digits.end(), nextdit;
	for (;dit != dend; dit++) {
		nextx = 5000;
		nextdit = dit;
		nextdit++;
		if (nextdit != dend) nextx = (*nextdit).rect.x;
		printf("Find char: %d, %d, %d, %d\n", (*dit).rect.x, (*dit).rect.y, (*dit).rect.width, (*dit).rect.height);
		if ((*dit).chr == 0) mpCheckChar->MatchDigit1117((*dit), toComp, index, minWidth, maxWidth, nextx);
		//if ((*dit).chr == 0) MatchDigit((*dit), img, index, minWidth, maxWidth, nextx);
		//if ((*dit).chr == 0) DetermineDigit((*dit), toComp, index, minWidth, maxWidth, nextx);
		else printf("had %c\n", (*dit).chr);
		ch = (*dit).chr;
		if (ch != 0) {
			text[textPos++] = ch;
			text[textPos] = '\0';
		}
		//dig = toComp((*dit).rect);
		//sprintf(temp, "get-%d.jpg", index);
		//imwrite(temp, dig, params);
		index++;
	}
	dit = digits.begin(), dend = digits.end();

	// check text position
	index = 0;
	textPos = 0;
	text[0] = '\0';
	for (;dit != dend; dit++) {
		if ((*dit).chr == 0) continue;
		text[index] = (*dit).chr;
		++index;
		text[index] = '\0';
		printf("verify: [%c] %d - %d,%d\n", (*dit).chr, nextx, (*dit).rect.x, (*dit).rect.width);
		if (index == 1) {
			nextx = (*dit).rect.x + (*dit).rect.width;
			continue;
		}
		if ((*dit).rect.x > (nextx + 15)) {
			if (index == 3) {
				nextx = (*dit).rect.x + (*dit).rect.width;
				continue;
			}
			// last digit is not correct
			if (index == 4) {
				printf("Remove 3rd char: %c, %d\n", text[2], nextx);
				text[index - 2] = (*dit).chr;
				text[index -1] = '\0';
				index = 3;
				nextx = (*dit).rect.x + (*dit).rect.width;
				continue;
			}
		}
		nextx = (*dit).rect.x + (*dit).rect.width;
	}
	printf("Found cont: %d, digits: %d, text: %s\n", conts.size(), digits.size(), text);
	int len = strlen(text);
	outText[0] = '\0';
	for (int i=0;i<len && i<outBufSize;i++) {
		outText[i] = text[i];
		outText[i+1] = '\0';
	}
	return strlen(outText);
}


// good
bool ImageProc1::FindABox(std::list<ContInfo>::iterator &nit,	std::list<ContInfo>::iterator end,
		std::list<ContInfo> &cis, Rect &outRect, int locX, int locY, int width,
		int height, bool &is1, int digitIndex)
{
	if (nit == end) return false;
	Rect rect = ((ContInfo &)(*nit)).rect;
	cis.clear();
	int cnt = 0;
	// cis.push_back((*nit));
	int itmp;
	Rect rect1;
	ContInfo &rci = (ContInfo &)(*nit);
	for (;nit != end; nit++) {
		rci = (ContInfo &)(*nit);
		++cnt;
		printf("........ check: %d,%d,%d,%d, %d\n", rci.rect.x,
				rci.rect.y, rci.rect.width, rci.rect.height, rci.area);
		// check whether it is 1
		itmp = rci.rect.height - height;
		if (locX != 0 && itmp <= 5 && itmp >= -5
				&& rci.rect.width >= 2
				//&& ((ContInfo &)(*nit)).rect.width <= 8) {
				&& rect.width <= ((height + 1) / 3)
				&& ((rci.area * 2) > (rci.rect.width * rci.rect.height))
				) {
			if (cnt == 1) {
				nit++;
				printf("stop for 1\n");
				is1 = true;
				break;
			}

			// TODO??? handle 1 when it is at third digit or other digit
			bool cont = false;
			// if it is digit after third digit, "1" must be at fist or not too far from beginning
			if (cnt != 0) {
				if ((rci.rect.x + rci.rect.width - locX) < 13)
					cont = true; // continue with digit 1.
			}
			// continue with digit 1 or just a piece of other digit.
			if (cont) {
				is1 = true;
				if (rect.height >= 10 || rect.width >= 10) {
					// skip first one
					if (cnt == 1) nit++;
					break;
				}
				// otherwise, skip existing pieces
				rect = rci.rect;
				printf("stop 1\n");
				break;
			}
		}
		// stop when next piece is much out of rectange
		if (width != 0 && (rci.rect.x + rci.rect.width - rect.x) >= (width + 5) ) {
			printf("stop 1.5\n");
			// skip first one
			if (cnt == 1) nit++;
			break;
		}
		// skip the piece which is not in current digit rectangle
		if (digitIndex != 2 && width != 0 && (locX + width  + 8) <= (rci.rect.x + rci.rect.width)) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 2: %d,%d,%d,%d\n", width, locX, rci.rect.x, rci.rect.width);
			break;;
		}
		// stop when piece is out of box from height, it must be: top of out of box to inside, or inside to bottom of box
		if (height > 0
			// from top down, from outside of box into box, within width
			&& ((rci.rect.y + 7) < locY && (rci.rect.y + rci.rect.height) > (locY + 3)
					&& (rci.rect.x >= locX || (rci.rect.x + rci.rect.width) <= (locX + width)))
			// from inside of box to bottom outside of box
			&& (rci.rect.y >= locY && (rci.rect.y + rci.rect.height) > (locY + height + 7)
					&& (rci.rect.x >= locX || (rci.rect.x + rci.rect.width) <= (locX + width)))
			) {
				// skip first one
				if (cnt == 1) nit++;
				printf("stop 3\n");
				break;
		}
		/*
		if ((height > 0 && (((ContInfo &)(*nit)).rect.y + ((ContInfo &)(*nit)).rect.height - locY) > (height + 5))
			|| ((ContInfo &)(*nit)).rect.height >= gParams.MaxCharHeight) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 3\n");
			break;
		}*/
		// skip the piece when it is far from top of box
		if (locY > 0 && locY + 5 > rci.rect.y + rci.rect.height) {
			printf("skip 4\n");
			continue;
		}
		// skip the piece when it is far from bottom of box
		if (locY > 0 && rci.rect.y > locY + height && rci.rect.height >= 3) {
			printf("skip 4.5\n");
			continue;
		}
		//if (locY == 0) {
		//	itmp = (*nit).rect.x + (*nit).rect.width - rect.x;
		//}
		// make sure it is not overlap with height
		//if (rect.y + 5 > ((*nit).rect.y + (*nit).rect.height))
		//	continue;
		//else break; // invalid piece between it.
		itmp = ((ContInfo &)(*nit)).rect.x + ((ContInfo &)(*nit)).rect.width - rect.x;
		if (itmp > gParams.MaxCharWidth || itmp < 0) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 5\n");
			break;
		}

		itmp = ((ContInfo &)(*nit)).rect.y + ((ContInfo &)(*nit)).rect.height - rect.y;
		if (itmp > gParams.MaxCharHeight || itmp < 0) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 6\n");
			break;
		}
		// nit.rect.y might smaller than current rect.
		itmp = ((ContInfo &)(*nit)).rect.y + ((ContInfo &)(*nit)).rect.height - ((ContInfo &)(*nit)).rect.y;
		if (itmp > gParams.MaxCharHeight || itmp < 0) {
			// skip first one
			if (cnt == 1) nit++;
			printf("stop 7\n");
			break;
		}
		printf("........ : %d,%d,%d,%d - %d,%d,%d,%d\n", rect.x, rect.y, rect.width, rect.height,
				rci.rect.x, rci.rect.y, rci.rect.width, rci.rect.height);
		rect1.x = std::min(rci.rect.x, rect.x);
		rect1.y = std::min(rci.rect.y, rect.y);
		rect1.width = std::max(rci.rect.x + rci.rect.width, rect.x + rect.width) - rect1.x;
		rect1.height = std::max(rci.rect.y + rci.rect.height, rect.y + rect.height) - rect1.y;
		rect = rect1;

		cis.push_back((*nit));
		printf("........ added: %d,%d,%d,%d\n", rect.x, rect.y, rect.width, rect.height);
	}
	//
	if (height != 0 && ((rect.height + 5) < height || (rect.height - 4) > height)) {
		printf("    fail 1 : %d,%d,%d,%d,   %dx%d\n", rect.x, rect.y, rect.width, rect.height, width, height);
		return false;
	}
	if ((height == 0 || ((rect.height + 5) >= height && (rect.height - 5) < height))
		&& rect.height >= gParams.MinCharHeight && rect.height < gParams.MaxCharHeight
		&& rect.width < gParams.MaxCharWidth && rect.width >= gParams.MinCharWidth) {
		outRect = rect;
		// check weight, make sure 1 has most area filled.
		if (rect.width <= ((height + 1) / 3) && cis.size() == 1
				&& ((((ContInfo &)(*nit)).area * 2) > (((ContInfo &)(*nit)).rect.width * ((ContInfo &)(*nit)).rect.height)))
				is1 = true;
		return true;
	}
	printf("    fail 2 : %d,%d,%d,%d,   %dx%d\n", rect.x, rect.y, rect.width, rect.height, width, height);
	return false;
}


void ImageProc1::FindDigits(std::list<ContInfo> &conts, std::list<DigitInfo> &digits, std::list<ContInfo>::iterator it,
		std::list<ContInfo>::iterator end, int &maxWidth, int &minWidth, Mat &toComp)
{
	std::list<ContInfo> cis;
	Rect outRect;
	std::list<ContInfo>::iterator nit;
	Rect firstRect = Rect(0,0,0,0);
	int locX = 0, locY = 0, width = 0, height = 0;
	int itmp = 0;
	DigitInfo di;
	bool is1 = false;
	// find first digit
	int digitIndex = 0;
	for (;it != end;) {
		// find a cont
		printf("... finding: %d,%d,%d,%d\n", ((ContInfo &)(*it)).rect.x, ((ContInfo &)(*it)).rect.y,
				((ContInfo &)(*it)).rect.width, ((ContInfo &)(*it)).rect.height);
		// find a large piece for first digit.
		if (locY == 0 && ((ContInfo &)(*it)).area < 30) {
			++it;
			continue;
		}
		nit = it;
		is1 = false;
		if (FindABox(nit, end, cis, outRect, locX, locY, width, height, is1, digitIndex)) {
			if (digitIndex >= 6 && outRect.x > (locX + 17)) {
				outRect.x = locX + 3;
				outRect.y = locY;
				outRect.width = width + 5;
				outRect.height = height + 1;
				printf("Force using: %d,%d,%d,%d\n", outRect.x, outRect.y, outRect.width, outRect.height);
			}
			di.rect = outRect;
			di.cis = cis;
			if (is1) {
				printf("find 1\n");
				di.chr = '1';
			}
			else di.chr = 0;

			if ((digitIndex == 0 || digitIndex == 2) && !is1) {
				// it must be a valid digit
				int conf = mpCheckChar->MatchDigit1117(di, toComp, 0, minWidth, maxWidth, 5000);
				if (conf < 46) {
					// skip this letter
					printf("Skip first char for %c:%d%%", di.chr, conf);
					di.chr = 0;
					++it;
					continue;
				}
			}
			it = nit;
			printf("Found a box: %d,%d,%d,%d\n",
					outRect.x, outRect.y, outRect.width, outRect.height);
			if (locY == 0) {
				locY = outRect.y;
				height = outRect.height;
				width = outRect.width;
			}
			itmp = outRect.y - locY;
			// update y location because it can change (not always at same line)
			if (itmp < 5 && itmp > -5) locY = outRect.y;
			// mini x poistion for next char
			locX = outRect.x + outRect.width - 3;
			di.rect = outRect;
			di.cis = cis;
			digits.push_back(di);
			if (outRect.width > maxWidth) maxWidth = outRect.width;
			if (!is1 && outRect.width < minWidth) minWidth = outRect.width;
			++digitIndex;
		} else {
			it++;
		}
	}
}
