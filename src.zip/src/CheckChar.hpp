/*
 * CheckChar.hpp
 *
 *  Created on: Nov 17, 2018
 *      Author: peter1
 */

#ifndef CHECKCHAR_HPP_
#define CHECKCHAR_HPP_

#include <stdio.h>
#include <stdlib.h>
#include <list>

#include "ProcTypes.hpp"

class CheckChar
{
private:
	CharTemp			mpChars[MAX_CHAR_TYPE];

public:
		 				CheckChar			();
		 				~CheckChar			();

	int 				MatchDigit			(DigitInfo &di, cv::Mat &org, int index, int minWidth, int maxWidth, int nextX);
	int 				MatchDigit1117		(DigitInfo &di, cv::Mat &org, int index, int minWidth, int maxWidth, int nextX);

private:
	void				LoadChars			();
};



#endif /* CHECKCHAR_HPP_ */
