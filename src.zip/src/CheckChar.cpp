/*
 * CheckChar.cpp
 *
 *  Created on: Nov 17, 2018
 *      Author: peter1
 */

#include <stdio.h>
#include <stdlib.h>
#include <list>
#include "Utils.hpp"
#include "CheckChar.hpp"


CheckChar::CheckChar()
{
	memset(mpChars, 0, sizeof(CharTemp) * MAX_CHAR_TYPE);
	LoadChars();
}

CheckChar::~CheckChar()
{

}


void CheckChar::LoadChars()
{
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);
	char file[100], temp[100];
	Mat element = getStructuringElement(MORPH_RECT, Size(1, 1), Point(-1, -1));
	Mat mat;
	//Mat mat1;
	int cIndex = 0;
	for (int i=0;i<10;i++) {
		for (int j=0;j<MAX_IMG_PER_CHAR;j++) {
			if (j != 0)	sprintf(file, "tmpl-%d%d.jpg", i,j);
			else sprintf(file, "tmpl-%d.jpg", i);
			// printf("Load %s", file);
			sprintf(temp, "out-%d.jpg", i);
			if (Utils::FileExists(file)) {
				cIndex = i * MAX_IMG_PER_CHAR + j;
				mpChars[cIndex].ch = '0' + i;
				mat = imread(file, 0);
				resize(mat, mat, Size(0,0), 0.5, 0.5, INTER_AREA);
				//mat1.create(60, 60, CV_8U);
				//mat1 = Scalar(0,0,0);
				//mat.copyTo(mat1(Rect(15,15,mat.cols,mat.rows)));
				//threshold(mat1, mat1, 10, 255, THRESH_BINARY);
				threshold(mat, mat, 10, 255, THRESH_BINARY);

				//adaptiveThreshold(mat, mat, 255, ADAPTIVE_THRESH_MEAN_C, THRESH_BINARY, 11, 0);
				//medianBlur(mat, mat, 3);
				//Mat element = getStructuringElement(MORPH_RECT, Size(2, 2), Point(-1, -1));
				//morphologyEx(mat, mat, MORPH_CLOSE, element);
				//medianBlur(mat, mat, 3);
				imwrite(temp, mat, params);


				mpChars[cIndex].pMat = new Mat();
				*(mpChars[cIndex].pMat) = mat;
				mpChars[cIndex].width = mat.cols;
				mpChars[cIndex].height = mat.rows;
			}
		}
	}
	printf("Done load\n");
}

/****************************************************************************************************************/
/****************************  previous working version *********************************************************/

int CheckChar::MatchDigit(DigitInfo &di, Mat &org, int index, int minWidth, int maxWidth, int nextX)
{
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);
	Rect rect = di.rect;
	Mat dig1;
	if ((di.rect.width + 5) < maxWidth && (di.rect.x + di.rect.width + 5) < nextX) {
		// adjust width
		rect.width += 3;
		dig1 = org(rect);
	} else {
		if ((rect.width + 3) < maxWidth)
			rect.width += 1;
		dig1 = org(rect);
	}
	int db;
	int stopped = -1;
	// check whether or not most right are black, only leave 1 black column
	for (int i=dig1.cols-1;i>=0;i--) {
		for (int j=0;j<dig1.rows;j++) {
			db = (int) dig1.at<uchar>(j, i);
			if (db != 0) {
				stopped = i;
				break;
			}
		}
		if (stopped != -1) break;
	}
	db = dig1.cols - stopped - 1;
	Mat dig = dig1;
	if (db >= 1) {
		dig = dig1(Rect(0, 0, dig1.cols - db,dig1.rows));
	}
	char temp[200];
	sprintf(temp, "get-%d.jpg", index);
	imwrite(temp, dig, params);
	Mat tocomp;
	int col, row;
	double maxVal, minVal;
	Point maxLoc;
	Mat result;
	char chr = 0;
	double conf = 0;
	char temps[50];
	//double matchShapes(InputArray contour1, InputArray contour2, int method, double parameter);
	for (int i=0;i<MAX_CHAR_TYPE;i++) {
		// don't try to match '1', '1' should be recorgnize at beginning.
		if (mpChars[i].ch == '1') continue;
		if (mpChars[i].pMat) {
			//row = abs(dig.rows - mpChars[i].height);
			//col = abs(dig.cols - mpChars[i].width);
			//if (dig.rows < (mpChars[i].height + 2)
			//		|| dig.cols < (mpChars[i].width + 2)) {
			sprintf(temp, "Match %c: ", mpChars[i].ch);
			for (int j=0;j<4;j++) {
				resize(dig, tocomp, Size(0,0),
						1.0f + (mpChars[i].width + 1 + 2 * j - dig.cols) / (dig.cols * 1.0f),
						1.0f + ((mpChars[i].height + 1 + 2 * j - dig.rows) / (dig.rows * 1.0f)),
						INTER_LINEAR);
				cv::threshold(tocomp, tocomp, 10, 255, CV_THRESH_BINARY);
				matchTemplate(tocomp, *(mpChars[i].pMat), result, CV_TM_CCOEFF_NORMED);
				//sprintf(temp, "get-%d_%d.jpg", index,i);
				//imwrite(temp, dig, params);
				minMaxLoc(result, &minVal, &maxVal, NULL, &maxLoc);
				//printf("Match %c: %1.2f-%1.2f\n", mpChars[i].ch, maxVal,minVal);
				sprintf(temps, " %1.2f/%1.2f", maxVal, minVal);
				strcat(temp, temps);
				if (maxVal > conf) {
					conf = maxVal;
					chr = mpChars[i].ch;
				}
			}
			printf("%s\n", temp);
			//} else {
			//	matchTemplate(dig, *(mpChars[i].pMat), result, CV_TM_CCOEFF_NORMED);
			//}

			/*
			row = abs(dig.rows - mpChars[i].height);
			col = abs(dig.cols - mpChars[i].width);
			if (row > 3 || col > 3
					|| dig.rows < mpChars[i].height
					|| dig.cols < mpChars[i].width) {
				resize(dig, tocomp, Size(0,0),
						1.0f - (dig.cols - mpChars[i].width) / (dig.cols * 1.0f),
						1.0f - (dig.rows - mpChars[i].height) / (dig.rows * 1.0f),
						INTER_LINEAR);
				cv::threshold(tocomp, tocomp, 10, 255, CV_THRESH_BINARY);
				matchTemplate(tocomp, *(mpChars[i].pMat), result, CV_TM_CCOEFF_NORMED);
			} else {
				matchTemplate(dig, *(mpChars[i].pMat), result, CV_TM_CCOEFF_NORMED);
			}
			minMaxLoc(result, &minVal, &maxVal, NULL, &maxLoc);
			printf("Match %c: %1.2f-%1.2f\n", mpChars[i].ch, maxVal,minVal);
			if (maxVal > conf) {
				conf = maxVal;
				chr = mpChars[i].ch;
			}
			*/
		}
	}
	printf("conf: %1.2f\n", conf);
	if (conf >= 0.5f) {
		di.chr = chr;
		return conf * 100;
	}
	return 0;
}



int CheckChar::MatchDigit1117(DigitInfo &di, Mat &org, int index, int minWidth, int maxWidth, int nextX)
{
	if (org.cols <= 0 || org.rows <= 0) return 0;
	std::vector<int> params;	// set jpeg quality to 80
	// params.push_back(CV_IMWRITE_JPEG_QUALITY);
	params.push_back(1); //CV_IMWRITE_JPEG_QUALITY
	params.push_back(98);
	Rect rect = di.rect;
	Mat dig1;
	if ((di.rect.width + 5) < maxWidth && (di.rect.x + di.rect.width + 5) < nextX) {
		// adjust width
		rect.width += 3;
		dig1 = org(rect);
	} else {
		if ((rect.width + 3) < maxWidth)
			rect.width += 1;
		dig1 = org(rect);
	}
	int db;
	int stopped = -1;
	// check whether or not most right are black, only leave 1 black column
	for (int i=dig1.cols-1;i>=0;i--) {
		for (int j=0;j<dig1.rows;j++) {
			db = (int) dig1.at<uchar>(j, i);
			if (db != 0) {
				stopped = i;
				break;
			}
		}
		if (stopped != -1) break;
	}
	db = dig1.cols - stopped - 1;
	Mat dig = dig1;
	if (db >= 1) {
		dig = dig1(Rect(0, 0, dig1.cols - db,dig1.rows));
	}
	if (dig.cols <= 0 || dig.rows <= 0) {
		return 0;
	}
	char temp[200];
	sprintf(temp, "get-%d.jpg", index);
	imwrite(temp, dig, params);
	Mat tocomp;
	int col, row;
	double maxVal, minVal;
	Point maxLoc;
	Mat result;
	char chr = 0;
	double conf = 0;
	char temps[50];
	double resX, resY;
	//double matchShapes(InputArray contour1, InputArray contour2, int method, double parameter);
	for (int i=0;i<MAX_CHAR_TYPE;i++) {
		// don't try to match '1', '1' should be recorgnize at beginning.
		if (mpChars[i].ch == '1') {
			continue;
		}
		if (mpChars[i].pMat) {
			sprintf(temp, "Match %c: ", mpChars[i].ch);
			for (int j=0;j<4;j++) {
				resX = 1.0f + (mpChars[i].width + 1 + 2 * j - dig.cols) / (dig.cols * 1.0f);
				resY = 1.0f + ((mpChars[i].height + 1 + 2 * j - dig.rows) / (dig.rows * 1.0f));
				if (resX < 0 || resY < 0) {
					printf("Error res < 0: %1.2f, %1.2f\n", resX, resY);
					continue;
				}
				// printf("resize[%d, %d] %1.2f, %1.2f\n", dig.cols, dig.rows, resX, resY);
				resize(dig, tocomp, Size(0,0),
						resX,
						resY,
						INTER_LINEAR);
				cv::threshold(tocomp, tocomp, 10, 255, CV_THRESH_BINARY);
				matchTemplate(tocomp, *(mpChars[i].pMat), result, CV_TM_CCOEFF_NORMED);
				//sprintf(temp, "get-%d_%d.jpg", index,i);
				//imwrite(temp, dig, params);
				minMaxLoc(result, &minVal, &maxVal, NULL, &maxLoc);
				//printf("Match %c: %1.2f-%1.2f\n", mpChars[i].ch, maxVal,minVal);
				sprintf(temps, " %1.2f/%1.2f", maxVal, minVal);
				strcat(temp, temps);
				if (maxVal > conf) {
					conf = maxVal;
					chr = mpChars[i].ch;
				}
			}
			printf("%s\n", temp);
		}
	}
	printf("conf: %1.2f\n", conf);
	if (conf >= 0.40f) {
		di.chr = chr;
		printf("Found [%c] conf: %1.2f\n", chr, conf);
		return conf * 100;
	} else {
		printf("Skip conf: %1.2f\n", conf);
	}
	return 0;
}

